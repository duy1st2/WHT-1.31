﻿# WHT 1.31 — bản port đang phát triển

Source độc lập dựa trên WHT / WHT-1.29, dành cho **x86 / x64** Warcraft III 1.31.1.12164 và 1.31.1.12173. Đây chưa phải bản đạt đầy đủ tính năng của WHT-1.29.

## Build và chạy

Chạy `build-1.31.cmd` để build Release, chạy tests và cài vào hai bản sao bên dưới. Yêu cầu Visual Studio C++ Win32, CMake và .NET 10. `WHT.ini` đang có được giữ nguyên; file tool cũ được backup và file mới được kiểm tra SHA-256.

- `runtime-test/Warcraft3-1.31.1.12164/Run-WHT-1.31.cmd`
- `runtime-test/Warcraft3-1.31.1.12173/Run-WHT-1.31.cmd`
- `runtime-test/Warcraft3-1.31.1.12164/Run-WHT-1.31-x64.cmd`
- `runtime-test/Warcraft3-1.31.1.12173/Run-WHT-1.31-x64.cmd`

Đã copy đầy đủ hai client, gồm Data/CASC, x86, x86_64 và các thành phần đi kèm. Tool chạy **x86 / x64**. Không copy WHT.mix vào thư mục gốc của người dùng. Installer và launcher từ chối đường dẫn ngoài runtime-test của project; installer bỏ qua client đang chạy. Đóng client test rồi chạy lại installer nếu cần cập nhật.

1.31 không có Miles/mss32 như 1.29, nên dùng `Run-WHT-1.31.cmd` để cài build hiện tại và nạp DLL. Mở trực tiếp `Warcraft III.exe` không nạp tool. Launcher tự tìm đúng client test đang chạy để attach; nếu WHT đã nạp thì không nạp trùng. Muốn nhận DLL mới cần đóng game rồi chạy lại script. DLL xác minh SHA-256 của EXE và chữ ký các hàm native theo từng build trước khi cài hook luồng UI.

## Phần đã triển khai

- Profile riêng cho 12164 / 12173: CGameUI, CCameraWar3, CFloatVariable và các hàm frame/font/texture native.
- Menu native dùng danh mục tám tab của WHT, ngôn ngữ, phím menu theo cấu hình, cấu hình camera/FogZ, memory và macro. Các mục chưa port được khóa.
- Camera distance / far clipping qua hàm native, không sửa trang mã được game bảo vệ. Camera được tìm bằng RTTI vtable; giá trị được đọc qua getter native vì 1.31 mã hóa dữ liệu này.
- Macro ghi/phát/dừng/sửa; Ctrl+Shift+F9/F10/F12/F11 hoặc phím trong INI.
- Lệnh `#cam`, `#zoom`, `#fogz`, `#tool`, `#menu`, `#commandsettings`, `#full`, `#lock`, `#showmem`, các lệnh macro.
- Helper LoadFileMapWar3/session và updater riêng `toolinfo-1.31`, kiểm tra ProductName `WHT 1.31`, không chọn payload 1.29.

Gameplay cần phiên đăng nhập hợp lệ, mode Local và trận đang mở. `#fogz` ở đây là camera far clipping, chưa phải hệ thống scene fog. Chat command hiện nhận phím Enter/WM_CHAR, chưa có hook trạng thái chat native.

Runtime mount MPQ trong WHT.mix bằng API archive/provider native 1.31 và kiểm tra các tên font/icon/transparency được game giải quyết về đúng `CArchiveMpq` của tool trước khi dựng menu. Không thay icon hoặc texture trong suốt bằng hình stock, không đổi registry. Build cũng trích xuất 20 asset nguyên bản sang `dist/client-assets`; bản sao `WHT-assets` được giữ để kiểm tra/fallback. Font `fonts_VN.ttf` có glyph tiếng Việt; alpha của `Transparent.tga` bằng 0. Không nạp Storm.dll helper vào game; nó chỉ chạy trong chương trình trích xuất riêng.

## Chưa hoàn tất / chưa xác nhận

Chưa port các nhóm resource, t?y ch?nh thanh HP, MTH, time boss, auto skill/item, player/network và các chức năng khác không được mở trong menu; các header `*129` chỉ là tài liệu tham khảo và không được đưa vào runtime 1.31.

Build, helper self-tests và 2/2 CTest đã pass. Nạp DLL, chữ ký profile, callback luồng UI, session, mount MPQ/provider và camera readback đã pass trên cả hai client sao chép. Người dùng đã xác nhận #cam hoạt động trên cả 12164/12173, và button/dropdown/icon hết lem sau sửa asset/backdrop. Font/texture dùng đúng MPQ WHT; cờ visible, EdgeSize/inset và adapter widescreen dùng layout riêng 1.31. Macro, các hành vi chuyển trận và nhóm gameplay còn khóa chưa được đánh dấu pass. Computer-use đọc được cửa sổ nhưng chụp War3 timeout; visual pass ở lượt này dựa trên xác nhận người dùng.

Xem [PORT131.md](PORT131.md) và `analysis/build131-final.log`, `analysis/deployment-*.json`, log `x86/WHT.log` của từng client. Gói build nằm trong `dist/client-x86`; source có thể đóng bằng `package-source.ps1`.


## Ghi ch? x64

Source x64: `native/profile64.hpp`, `version64.cpp`, `gameplay64.hpp`. Profile ???c x?c minh t? memory image/RTTI/disassembly ri?ng cho m?i EXE x64, kh?ng d?ng offset x86. ?? n?i menu/font/texture, camera/#cam/#fogz, cooldown, HP/s?MP/s, HP/Mana values/max, level hero v? n?n gi?n theo s?; macro/menu config/memory d?ng ph?n chung. C?c nh?m ch?a port c?a x86 v?n kh?a ? x64. C?c l?nh c?a s? `#full/#lock` v? updater x64 ch?a n?i; kh?ng t? ?p payload updater x86 l?n x64.

Build x64, ki?m tra ki?n tr?c PE c?a DLL/launcher v? tests con tr?/v?ng ??i frame/geometry pass. Hai b?n x64 ?? ???c c?i v?i backup, preserve INI v? hash, launcher n?p DLL. Menu/MPQ c?a build n?n x64 ?? c? log native pass tr?n 12173; build gameplay m?i v?n c?n ki?m tra trong tr?n tr??c khi ??nh d?u ch?c n?ng hi?n th? pass. Computer-use tr? `window capture timed out` sau retry; kh?ng d?ng ?? ?? suy ra visual pass.

## SellFast parity

Set the SellFast key in the menu, select your hero, hover one inventory item and press the key to sell only that item. Empty or unpawnable slots do not select another item. `#sellslot 1..6` selects an explicit slot. The Sell All icon and `#sellall` retain bulk sale behavior. Both architectures use the native synchronized sale worker. Gameplay confirmation of the shortcut remains pending.


## Multiplayer review (2026-10-17)

See [MULTIPLAYER-AUDIT.md](MULTIPLAYER-AUDIT.md). Process-wide #speed acceleration has been removed: only reset/no-op at 1x is accepted until an offline gate and isolated clock are verified. Earlier #speed 1..70 notes are superseded. Native order paths were reviewed, but real multiplayer validation is still pending; parity with older ports does not guarantee no disconnect.


## 2026-10-17: #speed restored by user request

Supersedes the acceleration restriction above. #speed [1..70] is enabled again on 12164/12173 x86/x64; no argument or 1 restores 1x. Uses the same continuous process-clock scaling policy as the inspected WHT/WHT-1.29 source (QPC, timeGetTime, GetTickCount), with lazy installation, rollback on hook failure and existing match/UI reset. GetTickCount64 remains unscaled for tool scheduling. No unverified 1.29 native game-speed RVA is called: this restores multiplier behavior, not complete implementation parity with its native base-speed setter. Multiplayer safety remains unverified.


## Auto Click Left / Right

In the shortcut tab, assign Auto Click Left and/or Auto Click Right. Press the assigned key once to start, again to stop. Each button toggles independently. Clicking pauses during chat, menus, macros, loss of focus and physical mouse/modifier input; it resumes on return. A new match resets both toggles. HotKeyHero/AutoClickInterval in WHT.ini controls the requested interval (5..1000ms, default10ms); actual cadence follows the existing UI scheduler. Available on both builds and architectures; live confirmation pending.


## Hero F1-F7 shortcuts

Assign Hero F1 through Hero F7 in the shortcut tab. These select hero portraits 1 through 7 using the game's native button callback. Press twice to use the game's normal camera-centering behavior. Empty/hidden slots do nothing; modifier/chat/menu/macro input does not trigger these shortcuts. Both 12164/12173 x86/x64 are implemented; live confirmation pending.


## Map multiboard shortcut

Assign the expand/collapse information-board key in the other-shortcuts tab to toggle the map's native multiboard. Choose a key other than Tab while Show Resource is enabled: its existing Tab shortcut retains priority. Maps without a visible initialized multiboard leave the key unchanged. Implemented on both builds/architectures; in-match confirmation pending.


## Hide Time Of Day UI

In Graphics, enable Hide Time Of Day UI to hide the stock day/night orb. Disable it to restore the previous local visibility. The tool match timer is independent. Available on 12164/12173 x86/x64; in-match visual confirmation pending.


## Hide Console UI

In Graphics, enable Hide Console UI to hide the game's Console frame. Disable it to restore its previous requested visibility. The tool menu uses a separate host. Implemented for both builds/architectures; live appearance remains unconfirmed.


## Hide Black Bar UI

In Graphics, enable Hide Black Bar UI to expand the game's scene viewport using the same anchor policy as WHT-1.29. Disable it to restore the captured layout. Console hiding is a separate setting. Available on both builds/architectures; in-match appearance remains unconfirmed.


## Mouse ToolTip UI

In Graphics, enable Mouse ToolTip UI to move game tooltips near the cursor using WHT-1.29's placement policy. Disabling, opening the tool menu or leaving the client restores the previous anchor when it has not been changed by the map. Both builds/architectures implemented; visual confirmation pending.


## Hide bars on invulnerable units

In Graphics, enable the option to hide HP/Mana bars when Invulnerable. Bars return through the game's native visibility checks when invulnerability ends or the option is disabled. Unit state and engine-requested visibility are unchanged. Both builds/architectures implemented; in-match confirmation pending.


## Player-colored HP bars

In Graphics, enable Color Player to tint HP bars with their owner's player color, using WHT-1.29's palette. Disable it to restore the captured engine tint when it has not been replaced by the game. Available on both builds/architectures; visual confirmation pending.


## HP/Mana text

In Graphics, enable Text Life/Mana Commas to group portrait HP/Mana numbers (e.g.12,345 / 67,890). Text Life/Mana No Hide keeps the numeric label when the game clears it solely for exceeding its width. The two options are independent; disabling restores native formatting/width policy. Both builds/architectures implemented; in-match confirmation pending.


## Stat text commas

In Graphics, enable Text Stats Commas to group native damage, armor and hero attributes (e.g. 12,345 - 67,890). Native bonus colors are preserved. Disable to restore captured native numbers, provided the game has not replaced that label. Both builds and architectures pass contracts; in-match visual confirmation pending.


## Match start sound

Enable Other Hotkeys -> Sound Start Game before entering a match. Plays the embedded start sound once on the first verified simulation clock sample within 0..5 seconds. Enabling mid-match or attaching late stays silent. Both 12164/12173 x86/x64 implemented; audible in-match confirmation pending.


## Graphics runtime repair (2026-10-17)

The current implementation supersedes the earlier font-hook approach: HP/Mana and stat formatting update the current native labels without patching executable pages. On x64 the stat panel scan includes the real 0x620..0x650 fields. Hide Console and mouse tooltip use the final HUD console, not the auxiliary console of the same class. HP player colors and invulnerability visibility are applied through guarded per-instance native stat-bar callbacks so the engine cannot immediately repaint them; all other native methods, RTTI, unit argument and return register are preserved.

Component discovery caches UI member offsets, rejects unreadable/scalar fields without exception-driven probing and throttles missing components. Static overhead font/layout writes happen only when needed. Both builds/architectures pass contracts; 12164 x86 and 12173 x64 have direct in-process text/color/console evidence. Actual perceived FPS and remaining visual combinations still need user confirmation; multiplayer was not tested.

Selection flicker repair (2026-10-17): the mouse-dispatch refresh was insufficient and has been removed. A guarded per-instance CGameUI::Update (slot12) callback now reformats current native HP/Mana and cached stat fonts after the engine updates the UI. It preserves the complete64-entry table, RTTI COL, two float arguments, context pointer and native return register. Discovery remains throttled100ms; the per-update path rechecks only current/cached portrait/stat fonts, without running gameplay commands, broad frame discovery or menu reconstruction. The four exact native profiles are recorded in analysis/ui-refresh-native-profiles.json. User confirmed12173x64 stat text no longer alternates between grouped/ungrouped values during repeated selection.

Remaining overhead blink had a separate policy error: native pooled HP frames detach between render passes. Mana/state/level eligibility no longer depends on that transient attached flag; children keep requested visibility and inherit actual clipping from the native parent. Authorization, per-unit settings and explicit invulnerability filtering still apply. This does not force hidden/offscreen parents to show. Visual confirmation of the latest overhead change is pending. Contracts cover512 native UI ABI/ordering/recursion calls,512 repeated native stat replacements without timer delay, stale selection ownership and overhead eligibility. x86 and x64 tests pass.


## 2026-10-17: Remove Mana bar; move overhead updates into native bar callbacks

Mana bar has been removed at the user's request. The three General menu controls, default INI section, x86/x64 CStatBar allocation/bind/tint paths and runtime logging for tool-created mana bars are gone. Legacy runtime INIs are preserved, but ManaBar settings are ignored and loaded flags are forced off. Native Warcraft HUD mana and numeric MP/s/HP/Mana value features remain available.

The previous parent-visibility-only adjustment did not resolve the user's reported overhead blinking. Timer-based world writes are now replaced by native CStatBar callbacks: Show27 refreshes the currently bound unit before native attachment, and Bind30/Update31 refresh after the native binding/update. The timer only discovers guarded HP roots and prunes caches; it does not keep hiding/showing overhead hosts or repainting HP outside the native bar phase. Cached unit ownership is refreshed at each paint callback, including pooled frames rebound to another unit. The existing exact four native profiles, RTTI, all unmodified virtual methods, unit arguments and native return values are preserved. Re-entry is bounded; no gameplay orders or simulation writes are introduced.

Owned value/level hosts retain requested visibility while the native parent clips them. Show/Hide and level-background geometry are applied only when needed. Mana text values and hero level remain independently configurable. The CGameUI text-formatting callback remains separate, because the user confirmed it stopped grouped/ungrouped stat-text alternation.

Validation: x86 contracts2/2, x64 contracts1/1; menu metadata has235 valid controls and no ManaBar entries. Contracts exercise512 pooled native bind/update transitions, callback ordering and recursion guards, plus512 repeated hidden/visible parent checks without repeated registration. Four runtime-test installs have backups and matching MIX/launcher SHA256 hashes (analysis/graphics-repair-installed-hashes.json). User confirmed on12173x64 that repeated selection no longer makes the HP bar and HP/Mana values blink. Live native logs show the verified Show/Bind/Update callbacks running during the match, with HP/Mana value and level display active. Multiplayer was not tested.

Final native check:12164x86 also executes the native UI and stat-bar callbacks in-match. Direct manager inspection found21 native HP roots, zero nested CStatBar mana frames, and11 owned value/level hosts, all retaining requested visibility (10 detached0100,1 attached0101). Evidence: analysis/native-bar-no-mana-live-12164-x86.json. This checks lifecycle policy without forcing hidden native parents to display. The project-created x86 verification client was closed after the check; no user client or original installation was stopped or modified.


## Quick Chat (2026-10-17)

In Chat Nhanh, enable Quick Chat and assign up to nine shortcut/text pairs. A fresh press sends that line using the native chat editor and its normal Enter handler. Use a shortcut not already assigned to menu, resource, macro, hero or skill/item actions: existing actions retain priority. Existing open chat, tool menus, modifiers, held/repeated keys, macros, loss of focus, disabled settings/session and UI changes prevent dispatch. Text must be valid UTF-8, visible, single-line and at most128 bytes; invalid text is rejected, never truncated. No repeat/automatic chat loop is added.

Both12164/12173 x86/x64 have exact guarded CChatEditBar/CChatEditBox profiles. Tests pass on both architectures, including native-call ordering/ABI, nine bindings, UTF-8 limits and changed-editor cancellation. User confirmed successful in-match message delivery on12173x64 after the actual CChatEditBox profile correction. The removed Mana bar stays removed.


## Repeat messages (2026-10-18)

Added `#repeat <1..10000> <text>` and `#repeat stop`, following WHT-1.29's finite count and 250ms cadence. Delivery reuses the exact guarded 1.31 native Quick Chat editor/Enter path on 12164/12173 x86/x64; no packet construction, simulation mutation, new hooks or timers. Text is one visible UTF-8 line, up to128 bytes; hash commands, malformed/control/multiline input and oversized text are rejected without truncation or replacing an existing queue. Stop clears the queue.

The existing UI scheduler submits at most one message per update. Native refusal retains the count and backs off250ms; late updates never replay missed periods. Typing, tool menu, macros, skill-learning sequence and background focus pause dispatch. Lost authorization, Local mode, command-settings enablement or UI/match replacement clears pending work. Quick Chat's master checkbox remains independent, as in1.29. Owned native chat state is revalidated between calls by the existing sender. No actual chat messages were sent by automated verification.

Usage: enter `#repeat 3 hello` to send hello three times; enter `#repeat stop` to cancel. Both architecture contract suites cover count boundaries, cadence, refusal, gating, completion, cancellation, new match and Vietnamese/UTF-8 input. In-match and multiplayer confirmation of this command remain pending.

Validation: analysis/build131-repeat.log2/2 and build64-repeat.log1/1 passed. All four runtime-test installs completed with backups, preserved INIs/logs/macros and verified MIX/launcher hashes (analysis/repeat-installed-hashes.json). Original installations untouched.


## Time Boss (2026-10-18)

Enabled MTH/TimeBoss and the MTH49Enable/G17Enable master controls on both12164/12173 x86/x64. Enable one master and Time Boss in the MTH tab. Other unported MTH actions remain unavailable. This uses the same TimeBossState rawcode groups and countdown policy as WHT/WHT-1.29: initial493/300/300-second schedule, periodic1007-second boss, observed group death31-second respawn, same-identity revival resets the corresponding timer. Intended for the matching MTH maps; it does not detect map identity or discover arbitrary boss types.

New time_boss131.hpp profiles exact native CUnit tables and rawcode offsets34(x86)/58(x64). Each profile guards CUnit virtual55 and its DWORD rawcode read, plus the corresponding verified hero-level function's high-byte A..Z classification instruction. Captured-image evidence and matching bytes are recorded in analysis/time-boss-native-profiles.json. Existing native object ID pairs distinguish reused pointers; unrelated classes/types are refused. Cached units are rechecked for exact class/code/identity before existing guarded native health readers are called. Invalid/disappeared objects are forgotten without inventing a death. Collection is bounded8192 entries.

Reuses the existing native HP Show/Bind/Update callback and registered HP snapshot, as the reference tracks observed/rendered units. No global unit enumeration, executable patch, new timer/hook, gameplay-state write or outgoing command. Active Time Boss participates in existing bar callback registration even if the other HP overlays are off. Health observations occur once per simulation second; clock reads/display cadence is at most4Hz, using the verified native simulation clock so pausing does not advance countdowns. Unknown clock hides timers. Disabled settings/auth/master/TimeBoss suspend collection and hide display; UI/match replacement clears state. Existing ToolMenuOverlay::UpdateBoss frames use the feature-level factory, preserving menu priority.

Validation: build131-time-boss.log2/2, build64-time-boss.log1/1 passed. Contracts cover exact per-profile object/rawcode layouts, supported groups, death countdown/no repeated death, revival and second death, reused identities, foreign classes, periodic schedule and match reset. Four runtime-test variants installed with backups, preserved INIs/logs/macros and verified MIX/launcher SHA256 (analysis/time-boss-installed-hashes.json). Original installations untouched. Actual MTH-map appearance/death timing and multiplayer testing remain pending.


## Manual screen/chat clear commands (2026-10-18)

Added the WHT-1.29 aliases `#clear` / `#cls` for native screen text and `#clearc` / `#clsc` for the on-screen native chat region. Commands accept no arguments. They are independent of the Delay Clear checkboxes/periods and do not change configuration. Available on12164/12173 x86/x64 using the existing exact MessageProfile131 clear routine/frame guards; no new native address, hook, timer, gameplay mutation or outgoing command.

New ManualClear131 queues at most one request per region for the current CGameUI. The existing UI scheduler waits for both the input typing latch and the exact native CChatEditBar mode to be closed, so command processing before native Enter completion does not clear the active editor. Tool menu/background context pauses dispatch; lost authorization, Local/settings gates, changed UI or a two-second deadline cancels the request. Requests are consumed before native calls, including refusal/re-entry, and never replayed. Unknown native editor/frame identity prevents clearing.

Validation: analysis/build131-manual-clear.log2/2 and build64-manual-clear.log1/1 passed. Contracts cover aliases, scope isolation/coalescing, native typing, context gates, deadline/UI/session cancellation, native refusal, unreadable editor and re-entry without duplicate execution. Existing per-architecture message-frame/clear-native contracts still pass. Four runtime-test installs completed with backups, preserved INI/logs/macros and matching MIX/launcher SHA256 in analysis/manual-clear-installed-hashes.json. Source packaged. Actual in-match visual confirmation and multiplayer testing remain pending; original installations untouched.


## Detailed damage/armor tooltips (2026-10-18)

Enabled Graphics/Detailed Stats Tooltip on12164/12173 x86/x64. Hover Damage to retain the native description and append attacks/sec, attack interval, raw attack-speed bonus and maximum attacks/sec; hover Armor to append numeric movement speed. The existing ASCII AttackSpeedTooltip/MovementSpeedTooltip text policy follows WHT/WHT-1.29. Toggling off restores native body text only while it still equals this feature's output. Ordinary and extended tooltips preserve their original title, body and extra description; the corresponding native tooltip builder recalculates size. No new feature frame or stock frame-level change.

New detailed_tooltip131.hpp and detail_tooltip_profile131.hpp use the existing post-native CGameUI Update callback. No executable patch, font detour, new timer, synthetic input, outgoing order or simulation write. Bodies are bounded1024 bytes including appended details; oversized results and unrelated/newer text are refused without truncation. The native panel's cached strings are read only. Requests never show a hidden tooltip or re-anchor it, so Mouse ToolTip policy remains independent. UI/match replacement forgets stale labels; menu/auth/settings gates suppress the extension and restore an owned visible body.

Profiles independently match CInfoPanelIconDamage/Armor, CAbilityAttack/Move, FloatMini/FloatMiniB and CToolTipWar3/CUberToolTipWar3 in all four captures. Native CAbilityAttack is unit+460/458 on12164/12173x86 and+570 onx64. Attack speed is FloatMiniB+1B0/value1B4(x86),+268/value270(x64); primary/secondary cooldown FloatMini+158/+160(x86) and+1D8/+1E8(x64). Read each property's native vtable before values. Exact native clamp code references the map minimum/maximum globals, rather than assuming0.2/5; both bounds participate in rate calculation. The four supplied captures currently contain approximately0.2/5. Native movement getters are3BD490/39B2D0(x86),42DFE0/495780(x64), called only for the current exact CAbilityMove whose owner back-pointer still matches the selected unit. Missing owner refuses the getter's native global-unit fallback.

Both normal/extended native builders have guarded entry bytes (masked x86 relocated absolute operands) and verified direct callers. Getter prologues, native attack/movement member-load instructions and exact minimum/maximum instruction targets are also guarded. Full evidence/signatures: analysis/detail-tooltip-native-profiles.json. The normal builder's reset/cost/item arguments and extended builder's extra/cost/item arguments match the native Damage/Armor calls. Selection identity is included in text ownership. Sources must match the exact native panel helper and current live CInfoBar member, not a tooltip text keyword or screen coordinate.

Panel discovery runs only while a native tooltip is visible; a complete three-panel cache validates its current member slots/classes/helper links instead of repeatedly scanning CInfoBar. Incomplete/changed discovery is throttled100ms. Text/layout calls occur only when current body differs from the desired body; native changes are reformatted after that native UI update. When disabled with no owned text, no tooltip polling is added.

Validation: analysis/build131-detail-tooltip.log2/2 and build64-detail-tooltip.log1/1 passed. The contract executables additionally loaded the real captured code for both builds in each architecture, relocated the two known x86 clamp operands to the audit buffer and verified every native code guard. Tests cover512 normal/extended ABI calls, primary/secondary periods, map min/max, movement owner/ABI, unchanged-write suppression, toggle restoration, foreign text, changed identity, oversize rejection, live panel-slot cache invalidation and hidden frame refusal. Four runtime-test installs completed with backups, preserved INIs/logs/macros and matching MIX/launcher SHA256 (analysis/detail-tooltip-installed-hashes.json). Source packaged. Actual in-match tooltip appearance and multiplayer testing remain pending; original installations untouched.


## Display-setting command shortcuts (2026-10-18)

Ported the following existing WHT-1.29 command aliases for already available display features on12164/12173 x86/x64. A bare command toggles its checkbox; append0 to disable or1 to enable, e.g. `#timer 1`, `#resource 0`, `#statscommas 1`. Only bare/0/1 syntax is accepted, following1.29. Settings persist in the current client's INI and the tool menu refreshes through the existing config reload. No new native address, timer, hook, gameplay mutation or outgoing action is introduced.

| Commands | Setting |
| --- | --- |
| `#timer`, `#showtimer` | Show Timer |
| `#res`, `#resource` | Show Resource |
| `#showhotkey` | Show Hotkey In Panel |
| `#statstooltip` | Detailed Stats Tooltip |
| `#statscommas` | Text Stats Commas |
| `#hpmpcommas`, `#hpmpnohide` | Text Life/Mana Commas / No Hide |
| `#sound` | Sound Start Game |
| `#showdropall`, `#showautopick`, `#showsellall` | Show corresponding inventory icon |
| `#console`, `#consoleui` | Hide Console UI (1 hides) |
| `#showskills` | Show Ins All Skills icon |
| `#showlevel` | Show Level Hero |
| `#blackbar`, `#mousetooltip` | Hide Black Bar UI / Mouse ToolTip UI |
| `#hpvalue`, `#manavalue` | HP / mana numeric value sub-option, subject to HP/Mana value master |

New view_commands131.hpp uses a shared fixed mapping for both architectures, validates the complete arguments before writing, and reloads only after successful persistence. Existing Local/session/current-match command gates apply. Each target continues to use its own existing runtime policy, restoration and dependencies; the command does not force a disabled parent option. Existing menu/window commands and unported features retain their prior availability. No runtime INI was modified by the implementation or tests.

Validation: analysis/build131-view-commands.log2/2 and build64-view-commands.log1/1 passed. Added isolated temporary-INI integration checks that persist/reload actual config, verify menu agreement and aliases, refuse malformed/multiline/NUL input without writes/reloads, and refuse failed persistence without publishing config. Temporary INI is cleaned up; no user config is used. Existing native profile and feature contracts also pass. Four runtime-test installs completed with backups/preserved INI-logs-macros and matching MIX/launcher SHA256 in analysis/view-commands-installed-hashes.json. Source packaged. Live command-entry/display confirmation remains pending; original installations untouched.


## Auto Click commands (2026-10-18)

Added WHT-1.29-compatible command control for the existing AutoClick131 worker on12164/12173 x86/x64:

| Command | Action |
| --- | --- |
| `#autol`, `#autoclickl` | Toggle repeated left click; append0/1 to disable/enable |
| `#autor`, `#autoclickr` | Toggle repeated right click; append0/1 to disable/enable |
| `#clickdelay 25` | Persist interval in milliseconds, range5..1000 |

Requires Local mode, authorization, an active match and command settings enabled. Left/right remain independent. Toggle state is session-only and resets on UI teardown; only the interval persists as HotKeyHero/AutoClickInterval. Successful changes reset the next-click deadline. Failed persistence and malformed arguments leave cadence/state intact. No new native profile, hook or timer. All dispatch retains the existing scheduler's focus, cursor-inside-client, physical-button/modifier, typing, menu, macro and inventory/skill-worker guards. Late scheduler updates never replay missed clicks; actual cadence remains limited by existing UI updates.

Validation: analysis/build131-auto-click-commands.log2/2 and build64-auto-click-commands.log1/1 passed. Isolated temporary-INI tests verify alias/toggle independence, interval persistence/boundaries, malformed/overflow/NUL refusal, failed-save behavior, blocked dispatch, paired mouse events, no catch-up bursts and teardown cancellation. Tests use a recording callback and send no actual clicks. Four runtime-test installs completed with backups and preserved user settings/logs/macros; MIX/launcher hashes match in analysis/auto-click-commands-installed-hashes.json. Live in-match command confirmation and multiplayer testing remain pending. Original installations untouched.


## Inventory drop commands (2026-10-18)

Added the reference WHT/WHT-1.29 inventory command interface for12164/12173 x86/x64:

| Command | Action |
| --- | --- |
| `#drop`, `#dropall` | Drop carried items from the selected owned living unit |
| `#dropitem <1..6>` | Drop only the item in that one-based inventory slot |
| `#quickdrop [0|1]` | Toggle or explicitly disable/enable Shift + right-click quick drop |

Quick Drop is a persisted Event/Quick Drop Item setting, matching the existing menu checkbox. The drop actions use the existing verified1.31 synchronized DropAllState/SendDropSnapshot131 path, including single-slot drops; they do not enable the inherited1.29 raw native inventory mutation path. No new native address, timer, executable hook, packet format or simulation write.

New drop_commands131.hpp parses complete arguments, captures the actual unit/session/object identities and requested item identities at command entry, then waits for both the tool typing latch and verified native chat mode to close. Focus/menu/macro/skill/inventory worker gates apply; pending requests expire after two seconds and are cleared on lost authorization/settings or UI replacement. A second pending request is refused. Before starting, the selected live owned unit/session is re-read through the existing native DropSnapshot131 guards. Only requested items still held with matching handle AND object identity enter the worker; newly acquired/replaced items are excluded. The request is consumed before worker start, including refusal/re-entry. Auto Pick stops only after a drop worker successfully starts. The existing worker revalidates each outgoing action, observes native inventory confirmation and cancels changed owners.

Show Drop All now governs icon visibility/input; it no longer cancels an active drop worker merely because the icon is hidden, allowing command use with no icon. Normal authorization/settings/focus/typing and worker exclusion gates remain. Idle command processing only checks a pending flag, with no periodic inventory scan.

Validation: analysis/build131-drop-commands.log2/2 and build64-drop-commands.log1/1 passed. Contracts cover full/slot syntax, all six slots, native open/unreadable chat, context pauses, current item filtering, replacement item/unit identity, session/UI/auth cancellation, timeout, empty slot/inventory, failed capture/start, one-shot consumption, worker submission/completion and actual temporary-INI Quick Drop persistence. Automated checks send no real game actions. Four runtime-test installs completed with backups, preserved INI/logs/macros and matching MIX/launcher SHA256 (analysis/drop-commands-installed-hashes.json). Source packaged. In-match and multiplayer validation remain pending. Original installations untouched.


## Quick Drop parity audit against current WHT-1.29 (2026-10-18)

Compared current1.29 quick_drop129.hpp, quick_drop_network129.hpp and version129.cpp input/command paths with1.31 quick_drop131.hpp, quick_drop_network131.hpp and both architecture dispatchers. Shift+right-click already uses a single synchronized action13/orderD0021 with queued flag1 and native unit/item identities; the DropAction serializer matches the current1.29 source exactly.1.31 retains its independently verified native API/layouts and CDataStore buffer ABI. No raw UnitRemoveItem call was enabled.

Fixed missing parity details: block new gestures while the native target-selection cursor is active or console HUD is hidden; enforce foreground-window gating onx86 as already done onx64; validate inventory hit bounds remain within0..0.8/0..0.6 like1.29; retain a consumed right-button gesture through duplicate down/double-click messages until its up event, even when modifiers/context change. The accepted gesture submits at most once before release. Off-inventory input passes through. Existing menu/chat/macros/auth/settings gates and native living/local-owner/slot/session/object-ID revalidation remain.

Scope distinction: this audit aligns the Shift+right-click gesture. The1.31 chat command #dropitem still intentionally waits for native chat closure and uses the previously documented bounded drop worker, whereas1.29 submits its command synchronously. Icon/drop-all worker policy is unchanged by this audit. No claim of byte-identical architecture-specific native adapters or live multiplayer validation.

Validation: analysis/build131-quick-drop-parity.log2/2 and build64-quick-drop-parity.log1/1 passed. Regression contracts cover duplicate down, latched double-click with changed context, one consumed release, canvas bounds, hidden button and classic/widescreen hit tests; existing native sender/session/item contracts continue to pass. Four runtime-test installs completed with backups, preserved INI/logs/macros and matching MIX/launcher SHA256 in analysis/quick-drop-parity-installed-hashes.json. Source packaged. Live gesture/multiplayer confirmation remains pending. Original WHT/WHT-1.29 sources and original Warcraft installations unchanged.


## Inventory execution flow correction (2026-10-18)

Supersedes the previous chat-wait queue and single-slot worker behavior documented in Inventory drop commands/Quick Drop parity audit. User requested reference flows rather than additional1.31 scheduling/retry policies.

Both x86/x64 now use one BeginQuickDrop helper for #dropitem and Shift+right-click. In the current1.29 order, it stops Sell All, defers Auto Pick for2000ms and submits one QuickDropNetwork131 synchronized action immediately. No native-chat wait, pending command queue, timeout, worker scheduling or automatic retry is used for a single item. Native refusal also keeps the reference pickup delay. The existing native session/unit/item/slot identity and ownership guards remain. Auto Pick's enable state and pending target are preserved during the pickup delay; x64 no longer turns Auto Pick off on a quick drop. Both architectures use the same flow helper policy. A hidden/blocked native target cursor, menu, input modifier and gesture-latch gates remain as audited earlier.

Removed DropCommandQueue131 and its runtime tick/reset paths entirely. #drop/#dropall now capture inventory and start the existing batch worker directly; no extra native-chat-close queue is layered ahead of it. The batch worker/DropAction serializer remains source-identical to WHT/native/drop_all.hpp (line endings normalized), including its one queued action per tick,100ms spacing and bounded confirmation/retry policy. This follows that WHT synchronized batch reference; WHT-1.29's separate raw-local UnitRemoveItem batch implementation is not enabled on1.31. Native layouts/ABIs remain independently verified1.31 profiles rather than inherited addresses. These references have distinct implementations and are not represented as identical.

Related outgoing entry-point review: Auto Pick uses the native selected-unit target order builder; Sell All uses the existing guarded synchronized shop action; skill learning uses native button activation; self/target cast retains cancel-before-submit ordering; Quick Chat/Repeat uses the native editor/Enter flow. None of those adapters was replaced or given additional sends by this change. This review is not a proof that every scheduling policy across all versions is identical. Broader Auto Pick/Sell All cadence/selection-policy equivalence and multiplayer validation remain open; no multiplayer disconnect-free guarantee is made. Reference source SHA256 snapshots: analysis/inventory-flow-reference-hashes.json.

Validation: final analysis/build131-inventory-flow-parity.log2/2 and build64-inventory-flow-parity.log1/1 passed. Contracts verify stop-sell/pause/send order, one submission per invocation, no retry on refusal,2000ms delay, retained Auto Pick switch and teardown reset, alongside the existing native ABI/object/session tests. Superseded queue tests were removed. Four runtime-test installs completed with backups and preserved INI/logs/macros; all eight MIX/launcher SHA256 match in analysis/inventory-flow-parity-installed-hashes.json. Source packaged. Original installations and WHT/WHT-1.29 sources unchanged. In-match/multiplayer validation pending.


## All Skills native listener compatibility (2026-10-18)

User reported the All Skills icon does not spend points. Existing12173x86 runtime log shows icon Start succeeds but sequences finish with submitted0. Found a concrete callback-guard incompatibility: SkillClick131 rejected any receiver vtable outside the executable image, including the registered per-instance CGameUI refresh table introduced for anti-flicker presentation.

New SkillListener131 keeps ordinary native receiver checks and permits only the exact registered UI owner with the exact registered proxy table, an original native table inside this executable, an unchanged virtual3 callback equal to that original table, and an invocation target inside the executable image. An unrelated object sharing the proxy, changed callback or invalid original table is refused. Native click entry/event signature guards remain; no callback is replaced, no hook/timer is added and no native address changes. All Skills still uses the existing reference open/learn/back sequence and bounded passes; no direct hero point mutation or new outgoing action format.

Validation: analysis/build131-skills-listener.log2/2 and build64-skills-listener.log1/1 passed. Added regression fixtures for original native receiver, registered UI proxy, foreign owner, altered callback and invalid original table; existing skill-point/open/learn/back/selection/click contracts remain. Four runtime-test installs completed with backups, preserved INI/logs/macros and matching MIX/launcher SHA256 in analysis/skills-listener-installed-hashes.json. Source packaged. This fixes a reproducible guard defect; actual in-match icon learning and multiplayer confirmation remain pending. Original installations untouched.


## Auto Pick toggle retention and Sell All confirmation cadence (2026-10-18)

Auto Pick's manual enable flag is no longer cleared by transient selection/session/native validation failure, hiding its icon, starting Sell All or the Drop All icon. Those events reset/pause only the current worker; the flag remains on until manual toggle or match/UI teardown. Full inventory already returned Waiting; the surrounding dispatcher now also retains enable state after temporary invalid snapshots. Invalid worker reads/submissions back off250ms instead of polling every UI tick. Selection/identity/ownership/life/session guards are unchanged; retaining the toggle never permits an invalid send. Sell/drop workers exclude pickup while active. Existing quick-drop2s delay remains; drop-all completion defers pickup2s and sell completion defers pickup1s as in WHT's inventory worker. Icon visibility is presentation-only. Both architectures share this policy.

Sell All was unnecessarily honoring its350ms/4s refusal/movement deadline even after native inventory confirmed the pending item disappeared. Ported WHT/native/sell_all.hpp's waiting_/confirming_ branch: confirmed disappearance replaces that deadline with25ms for independently updated resource state, then advances to the next original item. While the item is still held, the existing350ms/4s deadline and bounded shop/pass policy remain, so this does not add repeated outgoing orders. Native sender, packet content, shop access/pawnability/object/session checks and one-submit-per-Step limit are unchanged.

Validation: analysis/build131-pick-sell-cadence.log2/2 and build64-pick-sell-cadence.log1/1 passed. Contracts cover repeated full-bag waits, automatic resume after freeing a slot, transient invalid-snapshot backoff/recovery, near-shop confirmation advancing in25ms, far-shop early confirmation bypassing4s, unconfirmed far item still waiting, native sale confirmation/gold accounting, six single-slot cases and existing native sender guards. Four runtime-test installs completed with backups, preserved INI/logs/macros and matching MIX/launcher SHA256 (analysis/pick-sell-cadence-installed-hashes.json). Source packaged. In-match cadence/toggle and multiplayer validation remain pending. Original Warcraft and WHT/WHT-1.29 sources unchanged.


## Auto Pick Goku (2026-10-18)

Enabled MTHKEY/PickGoku and PickGokuDraw on12164/12173 x86/x64. Enable MTH49Enable or G17Enable, then use the assigned Pick Goku key, the Goku toolbar button, or `#goku` / `#autopickgoku`. Bare command toggles; append0/1 to disable/enable, matching1.29. The button uses the first visible reference MTH toolbar position(.305,.142,.038,.024), yellow when off and green when active, built through ToolMenuOverlay::Frame below settings-menu levels and hidden while that menu is open. Other unported MTH actions remain locked.

Only item rawcode I016(0x49303136) is eligible. Mode completes only after reading that type in the selected owned living unit's actual inventory, including the last slot of a full inventory; submission or disappearance from the ground alone does not count. Full bag without Goku waits. MTH master/session/settings loss clears Goku mode; ordinary Auto Pick's manual toggle remains independent. UI teardown resets the feature. Normal Auto Pick and Goku share one existing AutoPick131 worker and native order sender; Goku filtering takes priority while active and ordinary pickup resumes afterward only if its toggle was already on. Existing250ms scan cadence,777 radius, walking timeout/exclusion and sell/drop pause policies remain; no second order stream, new timer or simulation mutation.

New goku_pick131.hpp independently guards CItem virtual37 construction entries and exact prefixes that store the supplied rawcode at+34(x86)/+58(x64).12164/12173 constructors are BD31F0/B92DE0(x86),D39B70/D78510(x64), with the corresponding already verified exact CItem tables. Evidence: analysis/goku-item-code-profiles.json. Runtime code reads only the rawcode after exact CItem identity validation. No constructor is called. Snapshot filters candidates before selection and the type is checked again before the existing native pickup sender. Existing unit/item/session/ownership guards remain. Inventory completion is revalidated against current selection/session/life/ownership before disabling Goku.

Validation: analysis/build131-goku-pick.log2/2 and build64-goku-pick.log1/1 passed. Tests load both captured native images per architecture and verify table/constructor signatures (refusing modified bytes), check rawcode byte order/exact class, actual inventory capacity and full last-slot completion, unrelated item refusal, MTH control availability, button reset/input/double-click behavior, plus all existing Auto Pick native and policy contracts. Tests send no actual game actions. Four runtime-test installs completed with backups, preserved INI/logs/macros and matching MIX/launcher SHA256 (analysis/goku-pick-installed-hashes.json). Source packaged. Actual MTH-map pickup/button appearance and multiplayer validation remain pending; original installations untouched.


## MTH notifications and Goku button command (2026-10-18)

Enabled MTHKEY/Noti for the implemented Goku action on12164/12173 x86/x64. Successful manual On/Off and actual inventory-confirmed Goku acquisition now produce a four-second local in-game message, respecting the checkbox and Vietnamese/English language setting. Opening the settings menu hides the notice without extending its deadline; disabled notifications or lost session/settings/MTH masters clear it. UI teardown forgets owned frames. One reusable frame/font is created lazily via ToolMenuOverlay::Frame, below settings-menu levels. Text changes and visible transitions are applied only when necessary. No chat message is sent, native action callback added, outgoing order changed or simulation state written.

Added `#gokudraw`: bare toggles Show Goku Button;0/off/false disables and1/on/true enables, case-insensitive through the same pure ParseMthDrawValue129 helper as the reference. Only the already available Goku draw setting is exposed; unported MTH crafting/routes remain locked. The command persists MTHKEY/PickGokuDraw and reloads after successful save. Invalid/multiline/NUL/extra input and failed persistence leave settings unpublished. Button display remains subject to the MTH master; hiding it does not change active pickup mode.

Validation: analysis/build131-mth-notice.log2/2 and build64-mth-notice.log1/1 passed. Contracts cover lifetime, menu masking, preference/session cancellation, reset, bilingual text kinds, exact reference boolean aliases, isolated actual INI persistence, malformed input and failed-save behavior. Four runtime-test installs completed with backups, preserved INI/logs/macros and matching MIX/launcher SHA256 in analysis/mth-notice-installed-hashes.json. Source packaged. In-match appearance and multiplayer validation remain pending. Original installations and WHT/WHT-1.29 sources unchanged.


## Selected-unit MTH Chicken/Wolf routes (2026-10-18)

Enabled six route hotkey controls and their count dropdowns in MTH on12164/12173 x86/x64: ChayGa1..3 and ChaySoi1..3,1..20 laps. Commands #chicken1/#chicken2/#chicken3/#wolf1/#wolf2/#wolf3 take no arguments and use the corresponding configured count. Requires MTH49Enable or G17Enable. Select a living owned nonhero and keep it selected; changing selection/identity/session cancels future route orders. This implements the reference1.29 unassigned/selected-unit path. Pinned/assigned courier operation, delivery, base return and route toolbar buttons remain unavailable; the port does not silently change selection or advertise those paths as supported.

New mth_route131.hpp uses the exact six endpoint pairs from Mth129::routes,100ms polling,48-unit arrival threshold and30-second destination timeout. One Move order starts each leg; it is never repeated while walking. A lap decrements only after reaching the second endpoint. New valid requests replace an old route as in1.29. Disabled master/session resets; menu/chat/background/macro/skill/inventory workers pause dispatch. ReadSelfCastSource131 revalidates living local ownership, native session and identity; existing guarded CUnit rawcode/high-byte classification refuses heroes. Identity is re-read immediately before each native order. No raw position writes, new timer/hook or executable patch.

Independently verified native point-order builders emit action0x11, distinct from Auto Pick's action0x12 target-order builder. Entries C5F8E0/C1AA90(x86),DD7D30/E13EF0(x64). Five arguments are order0xD0012, auxiliary0, x/y float pointers, flags0. x86 direct callers B662E6/B26016 clean20 stack bytes; x64 callers CBBE77/CFBE87 use the matching Windows ABI and stack flags. Guards require entry prefix, action0xA0011 initialization, exact native point-action table reference and direct native caller; x86 additionally checks stack cleanup. Evidence: analysis/mth-route-point-profiles.json. Native point functions generate their own synchronized actions; no custom movement packet is constructed.

Validation: analysis/build131-mth-route.log2/2 and build64-mth-route.log1/1 passed. Contracts load both captured images per architecture and validate exact point profiles, refusing altered callers; x86 relocates only the known table operand into the audit buffer. Route tests exercise all six coordinates, two laps/four orders each,100ms cadence, no repeated walking orders, invalid route/count, pause, timeout, changed identity, disabled master, replacement request and native refusal. No actual game movement was sent by automated checks. Four runtime-test installs completed with backups, preserved INI/logs/macros and matching MIX/launcher SHA256 (analysis/mth-route-installed-hashes.json). Source packaged. Actual MTH-map movement and multiplayer testing remain pending. Original installations untouched.


## MTH route toolbar buttons (2026-10-18)

Enabled AutoGaDraw1..3/AutoSoiDraw1..3 menu controls on12164/12173 x86/x64. Six on-screen buttons Ch1..Ch3/Wolf1..Wolf3 call the same existing #chicken/#wolf handlers as assigned keys. No new movement order, packet, timer, native address or route policy is added. The selected-unit requirement remains; assigned/pinned couriers are not enabled by this change.

Added reference #ga1draw/#ga2draw/#ga3draw, #soi1draw/#soi2draw/#soi3draw and group #gadraw/#soidraw. Commands reuse FindMthDrawCommand129/ParseMthDrawValue129 pure settings logic:0/off/false disables,1/on/true enables; bare group disables all if any group member is on, otherwise enables all. Only implemented route display keys are accepted. Unported crafting display commands remain unavailable. Settings persist sequentially as in the reference, with one reload after successful completion; a failed write returns failure without publishing a reload. This is not an atomic multi-key transaction.

Toolbar packs visible Goku/route buttons into the reference6-column grid at(.305+.041*column,.142+.028*row), size(.038,.024). Hiding a button leaves no gap. Generalized the existing Goku button renderer to accept a static title, relocate an existing owned frame when layout changes and avoid unchanged label/geometry writes. Hosts use ToolMenuOverlay::Frame at feature level<=6 and hide while settings is open. Active route is green. Button mouse-down dispatches once; double-click does not repeat the request, and consumed release remains consumed after context changes. Chat/menu/background/macro/auth/settings gates remain.

Validation: analysis/build131-route-buttons.log2/2 and build64-route-buttons.log1/1 passed. Added actual temporary-INI tests for individual/group settings, reference aliases, bare-group behavior, malformed/NUL/extra input and failed save. Layout/input contracts cover seven-button row wrap, hidden-button compaction, logical route dispatch after compaction, double-click/release/context gating and UI reset. Existing native route profile/sequence tests remain passing. Four runtime-test installs completed with backups, preserved INI/logs/macros and matching MIX/launcher SHA256 in analysis/route-buttons-installed-hashes.json. Source packaged. In-match visual/button activation and multiplayer confirmation remain pending. Original installations untouched.

## Courier routes and toolbar alignment correction (2026-10-18)

Supersedes the selected-unit-only restriction above. Chicken/Wolf requests now prefer an explicitly assigned courier, otherwise an eligible selected unit, otherwise search the verified native unit list for an owned, living, moving nonhero with inventory (preferring one carrying items). `#setga` assigns the selected eligible courier. Discovery depends on the native list; explicit assignment remains available when discovery cannot find it. Buildings and immobile units are refused through independently guarded CAbilityMove getters. Pinned routes retain their courier identity while the player selects a hero/building.

Route dispatch uses the independently verified native selection sender (action 0x16) to temporarily select the courier, then the existing native point sender (action 0x11), then restores the full original selection through guaranteed cleanup. Both native selection sets must agree before dispatch. No simulation values or executable code are written. Native profiles, selection ABI and list offsets are verified separately for 12164/12173 x86/x64; evidence is in analysis/courier-selection-profiles.json. Actual multiplayer behavior still requires live testing.

Toolbar frames use one position anchor plus explicit size. Labels are centered using resolved native button bounds and the raw native frame API, matching the reference layout approach and avoiding a second viewport transform.

Validation: analysis/build131-courier-ui-fix.log passed 2/2; build64-courier-ui-fix.log passed 1/1. Contracts cover captured native signatures and modified-signature refusal, selection lists/cycles/capacity, native action arguments, full selection restoration including an injected exception, and resolved button rectangles. All four runtime-test targets were installed with backups and preserved settings; all eight MIX/launcher hashes match the builds (analysis/courier-ui-fix-installed-hashes.json). Original installations and WHT/WHT-1.29 sources untouched. A 12164 x86 test client was reopened; in-match visual and movement confirmation remains pending.

## Reference 1.29 native route queue update (2026-10-19)

Supersedes per-leg polling for Chicken/Wolf. The reference now submits a Stop followed by all configured pairs of Move endpoints into the engine queue. Version 1.31 now follows that dispatch policy on both builds and architectures: one native Stop (D0004, ability 0, flags 1, mode 4), then 2*count native world point calls (D0012, ability/target 0, order flags FFFFFFFF, queue 1), then restores the original selection. No further route position polling, arrival-based movement commands or automatic replay occurs after submission. Temporary selection is restored through SEH cleanup if a native call faults; already submitted game orders cannot be rolled back.

New mth_queue131.hpp verifies complete native wrapper instruction sequences, including direct native action-builder calls and ABI argument/return code. Independently captured RVAs: x86 12164 Stop B66200 / Point B66440; 12173 B25F30 / B26170. x64 12164 CBBD50 / CBC040; 12173 CFBD60 / CFC050. Captured evidence: analysis/mth-queue-profiles.json. No inherited 1.29 address is called.

Courier resolution now prioritizes the eligible selected unit, then the assigned courier, matching current 1.29. An explicitly selected/assigned moving hero-class map courier is accepted. Automatic search first prefers nonheroes, then permits hero-class fallback, preferring carried items and stable lowest identity among equal candidates. Automatic discovery still uses the previously verified 1.31 native CWorldFrame unit list, rather than the 1.29 rectangular query; discovery of units absent from that list is not established. #setga remains available. Original selection restoration preserves the full roster, including a building selection.

Validation: x86 2/2 and x64 1/1 passed in analysis/build131-native-route-queue.log and build64-native-route-queue.log. Captured wrapper checks pass for all four profiles. Native ABI fixtures validate Stop/move flags, twenty laps = forty alternating endpoints, selection restoration after success and exception, malformed count refusal, gated one-shot dispatch and no subsequent polling/replay. Four runtime-test installations completed with backups/settings preservation, and all eight build/installed artifact SHA256 hashes match (analysis/native-route-queue-installed-hashes.json). Actual in-map execution and multiplayer testing remain pending. WHT/WHT-1.29 sources and original Warcraft installations were not modified.

## Courier base and return commands (2026-10-20)

Added #gabase, #backga and #backsoi on 12164/12173 x86/x64. As in WHT-1.29, #gabase captures the position of the selected living owned unit; #setga assigns the courier; either return alias requests movement of that assigned courier to the saved point, independent of the current hero/building selection. Commands accept no arguments. Save/assignment can occur in either order within the same match. The point is kept only in memory and cleared on UI/match teardown.

CourierBase131 stores UI/session and exact courier object identity. Return requires an assigned living owned movable courier, a saved base in the same UI/session, settings and an enabled MTH master. It cancels a pending route request, waits for existing focus/chat/menu/macro/skill/inventory gates, revalidates the courier, consumes the request and sends one normal Move through the independently verified 1.31 native point-action sender. Existing native selection transaction restores the full original selection through guaranteed cleanup. The reference 1.29 return calls IssuePointOrderById; this port deliberately uses its verified synchronized native action path instead of inheriting that JASS/local order call. No Stop or queued round-trip laps are added for return. A new normal Move replaces the courier's old movement queue through engine handling. Native refusal is logged and never replayed automatically.

A pending return blocks new route/assignment requests until consumed or cancelled; disabling authorization/settings/MTH cancels pending return without forgetting the saved point. No periodic work occurs when idle. No new native address, timer, hook or simulation-state write.

Usage: select a living owned unit at the desired base and enter #gabase; select the Chicken/Wolf and enter #setga; select your hero/building and enter #backga or #backsoi. Enable MTH49Enable or G17Enable for return.

Validation: analysis/build131-courier-base.log passed 2/2 and build64-courier-base.log passed 1/1. Contracts exercise saved coordinates, assigned-unit independence, missing base, different session/UI, invalid numeric position, delayed dispatch, changed/reused courier identity, disabled master, teardown and single dispatch/no retries after refusal. Existing native sender ABI/selection restoration and captured profile tests remain passing. Four runtime-test installs completed with backups and preserved settings/logs/macros; all eight MIX/launcher hashes match (analysis/courier-base-installed-hashes.json). Actual in-map return and multiplayer testing remain pending. Original installations and WHT/WHT-1.29 sources untouched.

## In-game courier status feedback (2026-10-20)

Expanded existing MTHKEY/Noti feedback from Goku to implemented courier commands on 12164/12173 x86/x64. #setga, #gabase, Chicken/Wolf route requests and #backga/#backsoi now publish bilingual local status for courier assignment, base save/refusal, missing assignment/base, accepted requests and successful native dispatch/refusal. Messages say that commands were submitted, never that movement or laps completed. Queued request status is replaced by dispatch status when the scheduler actually sends. Missing courier/base feedback includes #setga and #gabase instructions. Existing logs remain.

Uses the same one reusable owned feature frame, four-second deadline, language switch, Noti preference, settings-menu masking, match teardown and authorization/MTH gates as Goku feedback. No chat is sent, outgoing order modified, native address enabled or timer/hook added. Invalid courier state rejected by the worker before its send callback can still cancel silently; completion/arrival tracking is not implemented or advertised.

Validation: analysis/build131-courier-notice.log 2/2 and build64-courier-notice.log 1/1 passed. Existing notice contracts now exercise all nine additional bilingual status kinds, command guidance, bounded lifetime, disabled-preference suppression and replacement of request by actual dispatch state; existing native action/selection contracts pass. Four runtime-test installs completed with backups and preserved settings/logs/macros. All eight MIX/launcher SHA256 hashes match builds (analysis/courier-notice-installed-hashes.json). Source packaged. In-match appearance and multiplayer testing remain pending. Original installations and WHT/WHT-1.29 sources untouched.

## Inventory slot information command (2026-10-20)

Added #islot on 12164/12173 x86/x64, following WHT-1.29 InventoryInfoText129: select a unit and enter #islot without arguments to display occupied zero-based slots 0..5 and four-character item rawcodes, e.g. [0: I016]. Empty inventory reports Empty/Trong; nonprinting rawcode bytes display as question marks. English formatting matches the reference exactly; Vietnamese labels follow the language setting. This command is read-only and does not create/copy/use/drop items.

New inventory_info131.hpp uses the existing independently verified inventory getters and CItem constructor/rawcode layout guards from Goku. It verifies exact unit/inventory/item classes, capacity <=6, and unchanged selected unit/object identity before publishing the snapshot. Invalid/partial reads preserve the caller's previous output and display a refusal message. A unit without an inventory component reports empty, matching the reference. No ownership/simulation mutation or native 1.29 RVA is used.

One reusable LocalInfo131 feature host displays command output for four seconds using ToolMenuOverlay::Frame at feature level <=6 and TextIn absolute placement. Settings menu masks it without extending lifetime; lost authorization/settings or UI teardown clears it. This output is independent of MTH/Noti because #islot is a general diagnostic command. No background inventory scan, new timer/hook or chat send. Text is also logged. Idle state performs no native inventory reads.

Validation: analysis/build131-inventory-info.log passed 2/2 and build64-inventory-info.log passed 1/1. Added shared contracts for reference formatting, byte order/nonprinting bytes, occupied last slot, changed identity, capacity overflow, stale slots beyond capacity, read failure/no partial publication, missing selection/native base, menu masking, expiry, lost authorization and teardown. Existing captured inventory/item guards remain passing. All four runtime-test targets installed with backups and preserved settings/logs/macros; all eight MIX/launcher SHA256 hashes match (analysis/inventory-info-installed-hashes.json). Source packaged. Actual in-match visual confirmation remains pending; multiplayer not tested. Original installations and WHT/WHT-1.29 sources unchanged.

## Native tool notification parity with current WHT / WHT-1.29 (2026-10-20)

notification_text.hpp is now byte-for-byte identical to both current reference trees (SHA256 A7074341D1A1A694F66397A29200002D16A8593376185CA0734727FA08BA0B43). It strips old Warcraft colors and repeated leading WHT tags, removes command tokens/empty command annotations, normalizes enabled/disabled to ON/OFF, inserts the toggle separator, uses yellow base text, green ON, red OFF and green setting values after Set ...:. It preserves UTF-8 bytes, with native user-facing labels selected in English like current 1.29 because the stock game message font lacks Vietnamese glyphs.

New notification131.hpp calls the independent 1.31 local CGameUI message wrapper, using native coordinates 0/0, duration four seconds and white base tint. x86 entries B11AF0 / AD1400 take the color value; x64 C5DC90 / CA0EC0 take a pointer to the color, copied by the wrapper before return. Complete wrapper byte guards include native relative layout/inner message calls and x86 absolute-constant relocation checks. Evidence: analysis/notification-native-profiles.json. Calls require the exact CGameUI or its registered UI-refresh proxy, validated native primary message frame and exact secondary CMessageFrame. Native refusal does not alter simulation state, retry or send chat. Diagnostic counters log native shown/refused attempts without idle work.

Implemented command/menu feedback now reports resulting checkbox state and configured setting/key values using complete English control labels. Camera, display commands, command settings, auto-click commands and other successful tool commands use the shared formatter. Unknown/refused commands are not announced as success; handlers with their own result skip generic duplication. Auto Pick icon, auto-click shortcut and command-settings shortcut publish ON/OFF. Sell start/terminal results, drop terminal results and all-skills submitted-count feedback use the same native renderer. These are dispatch/worker observations, not assertions that simulation effects succeeded beyond existing inventory confirmation.

Previous MTH and #islot overlay rendering is replaced by this same native message path, with one publish per event. MTH still obeys Noti and its existing menu/context gate; route submission text now matches MthRouteStarted129 including Ga/Soi route index and configured lap count. #islot uses the reference English slot text. No new tool overlay frame, native frame level change, background scan, worker thread or hook is introduced. Engine-owned message history/lifetime replaces separate overlay lifetime after dispatch; Clear Text and periodic text clear can clear these native messages, as in the reference.

Validation: analysis/build131-notifications.log passed 2/2 and build64-notifications.log passed 1/1. Added formatter output contracts, menu/config feedback tests, native ABI mocks for both color conventions, empty/NUL/oversize refusal, exact route/count text, and full captured native code guards for all four profiles with altered-byte rejection. Four runtime-test installs completed with backups/settings/log/macro preservation; all eight MIX/launcher SHA256 hashes match builds (analysis/notifications-installed-hashes.json). Source packaged. Actual in-match position/color/lifetime and multiplayer validation remain pending. Original installations and WHT/WHT-1.29 source trees untouched.

## Keyboard and edge-mouse camera scroll speed (2026-10-20)

Enabled Graphics -> Keyboard camera scroll (%) / Mouse camera scroll (%) and #kscroll <0..700> / #mscroll <0..700> on 12164/12173 x86/x64. Commands persist the existing Event/Keyboard Scroll Speed and Mouse Scroll Speed settings and reload only after successful save. Both menu and command paths use the same existing Config fields and camera update path. Shared native notification feedback reports the saved percentage. Keyboard scroll refers to arrow-key camera panning; mouse scroll refers to panning at the screen edge, not wheel zoom.

Matches current Scroll129 semantics: percent/100 is passed directly to the raw native setter; zero uses default speed 1.0. No legacy subtraction is applied. Each field independently captures the effective original value; unchanged updates do not call the setter. External changes during an active override become the latest restore baseline. Disabling Command Settings/authorization restores only when the current native field still equals the tool-written value, preserving intervening changes. Teardown attempts restoration while the camera class is valid, then forgets owners; inaccessible/replaced cameras are not written.

New scroll131.hpp independently guards both complete native setter bodies and all referenced constants for each profile, plus exact CCameraWar3 identity. x86 12164 AEE850/AEE8C0; 12173 AAD740/AAD7B0; fields 5A4/5A0. x64 12164 C372E0/C37350; 12173 C7DB60/C7DBD0; fields 78C/788. Setters normalize near-zero input to one, otherwise store the supplied speed. Evidence: analysis/scroll-native-profiles.json records captured bytes, x86 relocation operands and data constants. No inherited 1.29 native address, new timer, hook, executable patch, outgoing action or simulation-state write is used.

Validation: analysis/build131-scroll.log passed 2/2 and build64-scroll.log passed 1/1. New shared contracts verify setter ABI, percent conversion, zero/default sentinel, 700% maximum, no redundant writes, original/external restore policy, camera replacement, invalid native float, setter refusal, strict argument parsing, isolated actual INI persistence and failed-save behavior. Full native code/constant guards pass against all four captured images; altered code/data are refused. All four runtime-test targets installed with backups and preserved settings/logs/macros; eight MIX/launcher SHA256 hashes match builds (analysis/scroll-installed-hashes.json). Source packaged. Actual in-match panning and multiplayer verification remain pending. Original installations and WHT/WHT-1.29 sources untouched.

## Shared window commands and menu controls (2026-10-20)

Enabled borderless window and cursor lock on both 12164/12173 x86/x64 through one WindowServices131 implementation. Replaces the old x86-only ad hoc #full/#lock path and enables the previously unavailable x64 behavior. #full [0|1] and #lock [0|1] persist/toggle Window/Borderless and Window/Lock Cursor like current WHT-1.29; bare commands toggle. Other Hotkeys menu checkboxes now use those same canonical Window section keys (their previous Event keys did not match LoadConfig). Commands and menu changes share the existing UI update path. Configured preferences remain stored when Command Settings/session disables their effects.

Borderless captures the original style/WINDOWPLACEMENT, removes WS_OVERLAPPEDWINDOW and sizes to the current monitor. Disable/teardown restores captured style/placement. Native Win32 failures are checked, with style/placement rollback on failed entry. Private hidden windows retain hidden state on restoration. No topmost flag or forced activation is used. Cursor lock targets the game client rectangle only when foreground, not iconic and not in the tool menu. Focus/menu/minimize or disabled settings releases it through the existing UI scheduler. Background release preserves a different clip rectangle established by another application; foreground release follows the reference window-service policy. No ClipCursor API hook is added; only the window-service portion of 1.29 is ported here.

Added #wsize <width> <height> using reference outer-window limits 320x240..16384x16384. Refuses malformed/extra/newline/NUL input and invalid/minimized handles. Uses SetWindowPos without moving, changing Z order or activating the game. Notification reports observed outer and client sizes, matching 1.29 feedback. Window changes use Win32 APIs only: no new game RVA, simulation-state mutation, outgoing action, timer or hook.

Validation: analysis/build131-window.log passed 2/2 and build64-window.log passed 1/1. Shared contracts cover strict size parsing/bounds, all cursor focus/menu/minimize gate combinations, isolated actual INI persistence/independence/failed save, canonical menu values, and real Win32 resize/borderless/restore on a private hidden test window. No physical cursor clipping is exercised by automated tests. The prior project-created 12164 x86 client was identified by exact path and launcher parent PID before closing; user-created processes were not stopped. Four runtime-test installs completed with backups and preserved settings/logs/macros; all eight MIX/launcher SHA256 hashes match (analysis/window-installed-hashes.json). Source packaged. Actual in-game resizing, borderless transitions and cursor focus behavior remain pending. Original installations and WHT/WHT-1.29 sources untouched.

### 2026-10-24: Block opening the game option menu

- Added Event / Hide Option Menu to the other-hotkeys page: unmodified F10 and clicks on the standard native Menu button are blocked using the WHT-1.29 input policy.
- `#hidemenu 1` enables it; `#hidemenu 0` restores normal input. The existing `#menu` / `#tool` commands still control the tool menu. The configured tool-menu key has priority, including F10. Chat, focus and modifier gates are preserved; owned key/mouse releases are consumed together.
- This blocks opening the game menu; it does not hide the native button or close an already-open game menu. Mouse hit testing follows the reference centered classic 4:3 top-bar layout; map-relocated native buttons are not detected.
- No new native address, game-code patch, simulation order or worker thread. x86 contracts passed 2/2; x64 passed 1/1. Both 12164/12173 test copies were updated with backups and eight matching SHA256 checks (analysis/option-menu-installed-hashes.json). Original clients were untouched.
- In-match input behavior and multiplayer remain pending manual verification.

### 2026-10-24: State-value commands from WHT-1.29

Added #statetag and #hpmpvalue (same master switch, StateTag/Enable), plus #showmax (StateTag/ShowMaxValues), matching the current WHT-1.29 command-to-setting mapping. Accept 0/1 or no argument to toggle. These commands reuse the existing guarded state-value renderer and the normal menu configuration reload/notification path on both architectures. Turning the master off preserves maximum-value and per-unit preferences. No mana bar, native address, game order, timer or worker was added.

Validation: actual temporary-INI integration checks cover alias/master/menu agreement, independent maximum preference and reenable behavior, alongside existing malformed-input/failed-save checks. x86 passed 2/2; x64 passed 1/1 (analysis/build131-state-commands.log and build64-state-commands.log). All four runtime-test copies installed with backups and settings preservation; eight artifact hashes match (analysis/state-commands-installed-hashes.json). In-match and multiplayer verification pending. Reference sources and original clients untouched.

### 2026-10-24: Preset camera commands

Added #pcam and #pzoom using the current WHT-1.29 preset-camera policy: no argument sets 2400; a finite numeric argument is clamped to 500..6000. Both aliases persist Event/Camera and invoke the existing guarded camera update. Existing #cam/#zoom semantics are unchanged. Notification reports the resulting configured distance, including clamping. No native address, hook, worker or simulation order was added.

Validation: temporary-INI tests cover canonical camera persistence/reload, default, both clamp bounds, fractional value, extra arguments, overflow/nonfinite input, newline/NUL and failed-save refusal. x86 passed 2/2 and x64 passed 1/1 in analysis/build131-preset-camera.log and build64-preset-camera.log. All four runtime-test copies installed with backups and preserved settings/logs/macros; eight artifact SHA256 checks match (analysis/preset-camera-installed-hashes.json). In-match and multiplayer verification pending. Reference sources and original Warcraft installations untouched.

### 2026-10-24: Stop Courier/MTH

Added #stopga / #stopmth with no arguments, following the current WHT-1.29 cancellation intent. Cancels pending route and base-return requests and turns off Goku pickup, preserving the assigned courier, saved base and ordinary Auto Pick toggle. If the assigned courier is still a living owned movable unit in the same UI/session with the same identity, submits one native Stop D0004 (ability 0, flags 1, mode 4), temporarily selecting that courier and restoring the full original roster through SEH cleanup. This uses the already independently verified 1.31 native action sender rather than the reference local JASS order call. Native failure is not retried. Missing/invalid courier still permits local cancellation but the notification explicitly states no Stop was submitted. Does not automatically discover or stop an unrelated selected unit.

No new native address, code patch, polling worker or timer. Tests verify Stop ABI, exact select/Stop/restore sequence, no Move calls, exception cleanup/no replay, missing-courier refusal, already-selected optimization, cancellation preserving the saved base and subsequent return requests. Existing captured profiles and route/base tests passed. x86 2/2 and x64 1/1 in analysis/build131-courier-stop.log and build64-courier-stop.log. All four runtime-test targets installed with backups/settings preservation and eight matching artifact hashes (analysis/courier-stop-installed-hashes.json). In-match stopping and multiplayer remain unverified. Reference sources and original Warcraft installations unchanged.

### 2026-10-24: Player-color and invulnerable-bar commands

Added #colorplayer / #colorp (Graphics/Color Player) and #barinvul (Graphics/BarInvul), matching the current WHT-1.29 command names, canonical settings and 0/1/bare-toggle policy. These control existing 1.31 rendering features; no new renderer, native address, callback, worker or game order is introduced. Both architectures use the same command table and menu notification path. This does not restore the removed mana-bar feature.

Temporary-INI integration tests verify aliases, independent preferences, menu agreement and switching visibility back off. Existing native bar/color guards and malformed-input/failed-save checks remain passing. x86 passed 2/2 and x64 1/1 in analysis/build131-bar-commands.log and build64-bar-commands.log. All four runtime-test targets updated with backups and preserved settings; eight matching artifact SHA256 checks in analysis/bar-commands-installed-hashes.json. Source repackaged. Actual in-match command/rendering and multiplayer verification pending. Original clients and reference sources untouched.

### 2026-10-24: Explicit configuration reload

Added #reloadconfig with no arguments, matching WHT-1.29. Reads WHT.ini immediately using each architecture's existing configuration loader, refreshes menu values/language and applies the existing camera update. Uses normal authorization/match gates. It does not write settings or restart workers, resend courier actions, alter authentication, or enable unavailable native features. Existing periodic reload remains unchanged; settings that require process restart still require it. One native notification confirms reload.

Temporary-INI integration test edits Camera externally, explicitly reloads and verifies the new value without a setting write; malformed extra arguments, newlines and embedded NUL cannot trigger reload. x86 passed 2/2 and x64 1/1 in analysis/build131-reload-config.log and build64-reload-config.log. Four runtime-test installs completed with backups/settings preservation; eight matching SHA256 checks in analysis/reload-config-installed-hashes.json. Source repackaged. In-match and multiplayer confirmation pending. Reference sources and original clients unchanged.

### 2026-10-24: MTH mode commands

Added #mth49 and #g17 with the current WHT-1.29 mode-switch policy: enable one disables the other first; disable one leaves the other unchanged; no argument toggles. Accept 0/1, on/off and true/false. Saves canonical MTHKEY/MTH49Enable and G17Enable then reloads once after success. Reference sequential persistence is retained, not an atomic multi-key transaction: if the second write fails, the other mode may already be disabled on disk; failure returns without success feedback or immediate reload. Existing periodic reload can subsequently observe the saved first change.

Added #mthnoti [0|1] (bare toggle) using the existing MTHKEY/Noti checkbox. No crafting/delivery feature is newly enabled; commands only control already ported MTH features through existing gates. No new native address, timer, worker or game action. Integration checks cover exclusive enabling in both directions, bare toggle, inactive-mode disable preserving active mode, independent notifications, malformed input and second-write failure. x86 passed 2/2; x64 1/1 in analysis/build131-mth-modes.log and build64-mth-modes.log. Four runtime-test installs with backups/settings preservation; eight matching hashes in analysis/mth-modes-installed-hashes.json. Source repackaged. In-match/multiplayer verification pending; reference sources and original clients untouched.

### 2026-10-24: Exclusive MTH mode switching from menu

Fixed a reference parity gap: #toolui checkbox changes to MTH49Enable/G17Enable now call the same ApplyMthMode131 persistence path as #mth49/#g17, on both architectures. Current WHT-1.29 ToolMenuSetting129 also disables the opposite mode before enabling the requested checkbox. Toggling off leaves the other mode alone. Notification and checkbox refresh use the resulting loaded settings. Other controls retain their existing save behavior. This applies to subsequent menu changes, not automatic migration of an INI already containing both modes enabled. Sequential-save failure semantics remain as documented above.

Integration tests enumerate the actual menu descriptors, select both mode controls through the shared save path, verify exclusive loaded values and both checkbox reads, and refuse unrelated section/key mappings. x86 passed 2/2 and x64 1/1 in analysis/build131-mth-menu-parity.log and build64-mth-menu-parity.log. Four runtime-test installs completed with backups/settings preservation and eight matching artifact SHA256 checks (analysis/mth-menu-parity-installed-hashes.json). Source repackaged. No native address, game action, worker or frame-level change. In-match visual/input and multiplayer verification pending. Reference sources and original clients untouched.

### 2026-10-24: Casting mode now drives original hotkeys

Fixed unused Event/ModeCast: native default skill/item hotkeys now quick-cast at the cursor when mode is 1, following current WHT-1.29 NativeCastKey129 and the byte-identical pure casting_mode.hpp selector. Tool remaps (including failed bindings), self/target casting and learning bindings keep priority. Inventory requires an occupied usable slot; native skill keys require populated action data. Existing target mode, menu/chat/background/modifiers, macro and all-skills gates prevent interception. Uses existing guarded 1.31 button/target readers, native button click and foreground/viewport-checked cursor input. Claimed key repeats/releases are consumed through existing remap ownership. No new address, native code patch, packet, timer or background polling.

Corrected menu labels/range to Normal (0) and Quick Cast (1), matching current 1.29; removed nonfunctional Smart Cast/Quick Cast Old choices. Legacy value 2 and malformed values load as Normal without rewriting INI. Per-slot Quick Cast options remain independent. A targeted cast relies on native target activation; if cursor input cannot be submitted, normal native targeting remains available rather than retrying automatically.

Tests cover original skill/inventory key resolution, normal-mode pass-through, empty/unusable inventory refusal, remapped command/inventory/shop key priority, plus existing quick-cast activation and captured native profiles. x86 2/2 and x64 1/1 passed in analysis/build131-native-cast.log and build64-native-cast.log. Four runtime-test installations completed with backups/settings preservation and eight matching artifact hashes (analysis/native-cast-installed-hashes.json). Source repackaged. Actual in-match casting and multiplayer verification pending. Original clients and reference sources unchanged.

### 2026-10-24: Casting mode chat commands

Added #mc / #modecast as in current WHT-1.29: 0 = Normal, 1 = Quick Cast, no argument toggles. Persists Event/ModeCast and reloads through existing configuration path; normal command feedback reports the resulting mode name. No new casting implementation, native address, input injection path, worker or game action added by this command. Existing claimed-key ownership is preserved across a mode change so releases remain paired.

Temporary-INI integration checks cover explicit Quick Cast, bare switch back to Normal, menu agreement, malformed/extra/unsupported values and failed-save no reload. x86 passed 2/2 and x64 1/1 in analysis/build131-cast-mode-command.log and build64-cast-mode-command.log. All four runtime-test copies installed with backups/settings preservation and eight matching hashes (analysis/cast-mode-command-installed-hashes.json). Source repackaged. In-match and multiplayer validation remain pending. Original clients and reference sources unchanged.

### 2026-10-24: Click resource header to collapse/expand

Added Show Resource header mouse handling following current WHT-1.29 ResourceBoard129::Mouse: left down/double-click captures the header, release inside toggles expanded state. Drag outside consumes the release without toggling. Context/menu changes also consume an owned release without toggling, avoiding an unmatched map click. Hidden/unready headers never capture input. Uses the actual existing 1.31 header rectangle and viewport projection, not inherited 1.29 layout offsets. Tab continues to use the same expanded state. A toggle requests refresh at the next existing UI update; no new timer or worker.

Automated tests cover actual projected header bounds, press/release, collapse refresh, double-click sequence, drag outside, context change, right-click, hidden state and reset. x86 passed 2/2; x64 1/1 in analysis/build131-resource-mouse.log and build64-resource-mouse.log. All four runtime-test copies installed with backups/settings preservation and eight matching artifact hashes (analysis/resource-mouse-installed-hashes.json). Source repackaged. No player eligibility/data/order changes; no stock frame levels modified. In-match visual/input and multiplayer verification pending. Original clients and reference sources untouched.

### 2026-10-24: Resource board state indicator and UI caching

Following current WHT-1.29 resource board presentation policy, the header now uses native scrollbar UpArrow while expanded and DownArrow while collapsed. Texture changes occur only on the first presentation/state change. Each cell caches its last font pointer and rendered string; unchanged text is not resent to the native font setter. Row/header visibility is tracked, avoiding repeated Show/Hide calls for unchanged presentation. Board/UI reset discards these caches. Existing one-second resource sampling and eligibility rules remain unchanged. No measured FPS improvement is claimed.

Existing build/contracts passed x86 2/2 and x64 1/1 in analysis/build131-resource-ui-cache.log and build64-resource-ui-cache.log. Four runtime-test copies installed with backups/settings preservation and eight matching hashes (analysis/resource-ui-cache-installed-hashes.json). Source repackaged. Arrow visuals, long-running UI behavior and multiplayer remain pending live verification. No native address, game action or stock frame-level change. Reference sources and original clients untouched.


## 2026-10-25: MTH crafting and courier delivery

Implemented the remaining five MTH purchase/combine actions on 12164/12173 x86/x64: Shield, Ice, Wild, Frozen and Phoenix. Enable MTH49 or G17, select your living Hero and use the configured MTH hotkey, toolbar button, or #shield / #ice / #wild / #frozen / #phoenix. Shops must be within 777 of the Hero. Recipes use the shared reference rawcodes, ingredient checks, gold gates and memory-to-command-grid mapping. #shielddraw, #icedraw, #wilddraw, #frozendraw, #phoenixdraw and #mthdraw control button visibility. Existing Goku/route buttons keep their positions; crafting buttons follow them and wrap at six columns.

Requests wait for chat to close and the normal UI context to become ready. Shop selection uses independently captured CSelectionManager native group-selection profiles, not the courier's network-selection-only sender. Native entry, hero-bar caller ABI, UI member and manager table are verified separately for all four profiles. The original selection roster is saved and still-valid members are restored after completion/refusal, provided the user has not selected another unit. Missing command cards time out after 1500ms. Partial purchases and native refusal are never replayed; submitted means the purchase/combine commands were sent, not that the map confirmed the final item.

Courier delivery: select a living owned movable nonhero and use #setga, place items in its inventory, select your Hero and use #ga / #soi / #courier / #chuyendo. If the selected unit is not an eligible Hero, the nearest living owned Hero with inventory is found in the existing native unit list (distance, then identity tie-break). If no base has been saved in this match, the courier's current position is saved automatically. Approach uses existing synchronized native Move orders at most once per second. Within 300 units, send one item through the existing verified action 0x13 / D0021 sender with the Hero as recipient, preserving the complete selection roster through SEH cleanup. Wait for that exact item identity in the Hero inventory before continuing. Empty courier or full Hero queues return to the saved base; an unconfirmed receipt, invalid unit, native refusal or 60-second deadline stops. #backga/#backsoi cancels delivery and returns; #stopmth/#stopga cancels queued crafting and delivery as well as existing MTH actions. Automatic pickup/clicking and competing inventory actions are gated during these sequences.

Validation: shared recipe/queue, slot mapping, selection ABI, all four captured selection code guards with altered-byte refusal, courier receipt/full-bag/no-replay/deadline and command/display contracts. x86 and x64 CTest results are in analysis/test131-mth-completion.log and test64-mth-completion.log. No original Warcraft installation, WHT or WHT-1.29 source was modified. Actual MTH-map purchases, delivery, toolbar visuals and multiplayer remain pending live verification. No guarantee of a map result or multiplayer compatibility is claimed.

## HP bar size (2026-10-25)

In a match with Command Settings enabled, #whp 0.06 changes HP bar width and #hhp 0.004 changes height. Values are native UI units, accepted from 0 through 100. #whp 0 and #hhp 0 restore their original dimensions independently. Settings are retained in WHT.ini. Available on 12164/12173 x86/x64; actual appearance still needs in-match confirmation.

## Auto Skills (2026-10-25)

Enable Auto Skills in the automation tab. Select your caster, hover an offensive skill button and press Ctrl+Alt+1 through Ctrl+Alt+9 to assign its place in the sequence. Use the configured start/stop key or #autoskills 1 to run; #autoskills 0 stops. Set delay and search range in the same tab. Bindings are per unit and reset between matches. The worker chooses living visible enemies and pauses during chat/menu, manual targeting, focus loss, macros and competing inventory/MTH/auto-click/auto-pick actions. In-match casting and FPS still need live confirmation on each build/architecture.

Auto Skills: use #autoskilllist to inspect occupied sequence slots, #autoskillclear 1..9 to remove a step, or #autoskillclear all to clear the selected unit. Removing the last step stops automation.
`nAuto Skills editing: #autoskillswap 1 3 exchanges two steps (an empty slot moves the step); #autoskilldelay 0.5 sets seconds between attempts; #autoskillrange 1024 sets target radius. Delay accepts 0.05..10; range 128..4096. Numeric settings persist and sync with the menu.

Auto Heal (x86/x64): select your unit, register a healing item with #healitem 1 (slot 1..6), set #healhp 35 (1..99 percent), then #autoheal 1. Stop with #autoheal 0. Item types and settings persist; only the selected living owned unit is serviced. Uses 200ms sampling and 1500ms attempt backoff; live potion behavior is pending confirmation.

Auto Mana (x86/x64): select your unit, use #manaitem 2 to register the item type in slot 2 (accepts 1..6), #healmp 35 for the mana percentage (1..99), then #automana 1. #automana 0 stops it. Mana and healing lists persist independently; HP attempts take priority and share 1500ms spacing with mana attempts. Actual item use remains pending live confirmation.

Potion default correction: Auto Heal automatically scans all six slots for standard phea/pghe potions; Auto Mana scans for pman/pgma. No #healitem/#manaitem is required for those defaults. Enable with #autoheal 1 and #automana 1, set thresholds with #healhp / #healmp. Registration is optional for custom map item types and never pins an inventory position. Explicit saved ItemTypes overrides are preserved.

Auto Heal / Auto Mana can now be enabled and configured in F8 > Automation (Tự động). Each has its own switch and integer threshold 1..99 percent. Settings are shared with #autoheal/#healhp and #automana/#healmp. Standard potions are found in any of six slots without registration.

### 2026-10-25: Finish deployment of 1.29 menu layout
Compared current descriptors to WHT-1.29: 237 shared controls have matching pages and both rectangles (Window aliases mapped for comparison). Automation uses reference right-column potion controls and original Macro positions; 1.31 potion defaults remain 35. Restored reference grid-before-controls visibility order so hotkey labels are shown after their grid backgrounds. Kept 1.31 native adapters and reserved menu levels 7/8/9.
Build/CTest passed x86 2/2 and x64 1/1 (analysis/layout129-final-x86.log and layout129-final-x64.log). Installed both architectures in both runtime-test profiles with installer backups and SHA256 verification. Eight INI/log/macro hashes preserved (analysis/layout129-final-preserved.json). Original clients and WHT-1.29 unchanged. In-game visual confirmation remains pending.

### 2026-10-25: Native VSync and FPS unlock
Enabled Graphics/VSync and Graphics/Unlock Limit FPS on both builds and architectures. VSync uses the engine's native numeric-settings dispatcher key 19 (renderer virtual setter); FPS unlock submits a zero-millisecond minimum interval through the same native scheduler setter used by dispatcher key 17 (maxfps). Disassembly of all four profiles verifies maxfps conversion trunc(1000/fps) milliseconds. No 1.29 addresses, protected-code writes, graphics hooks, registry writes or additional workers/timers are used.
The existing UI update applies changes with a 500ms throttle and no repeated writes while preferences are unchanged. Requires authorized Local gameplay, tool settings and CGameUI. VSync takes priority: enabling it restores the current native maxfps preference before enabling sync. Disabling unlock restores that native maxfps value; zero restores through the zero-interval setter without dividing by zero. Losing authorization/settings/UI or normal teardown restores the native VSync preference as well. Tool overrides do not overwrite the native settings store. Changes made through stock game options can take effect until the tool preference changes or is re-enabled; the tool does not continuously force values. Renderer/driver behavior and actual FPS remain unverified in a match.
Profiles and generation evidence: native/presentation_profile131.hpp, analysis/presentation-profiles.py and presentation-profiles.json. Runtime verifies singleton access, setting reader, dispatcher, jump tables, relevant cases, native scheduler setter and renderer wrapper bytes before using a profile. Unknown/mismatched profiles or uninitialized native settings/renderer refuse actions. Restoration failures retain ownership and retry while the UI update is available.
Validation: x86 2/2 and x64 1/1 CTest passed (analysis/presentation-x86.log and presentation-x64.log). Contracts cover authorization, VSync priority/order, transition-only writes, native-setting restoration including external preference changes, refusal/retry, zero maxfps and relocated signature/tamper checks for both builds. Tests do not alter a live renderer. All four runtime-test variants installed with backups; eight artifact hashes verified in analysis/presentation-installed-hashes.json and eight INI/log/macro hashes preserved in presentation-preserved.json. Original clients and WHT/WHT-1.29 unchanged. In-match appearance, FPS effect and multiplayer confirmation remain pending.

### 2026-10-25: VertexColor, Fog Click and Fast Menu
Enabled Graphics/VertexColor, Event/Fog Click and Event/Fast Menu on 12164/12173 x86/x64. The implementation is independent of the 1.29 headers and verifies native code/data profiles before activation. Profiles, PE relocation normalization and evidence are in native/menu_fog_vertex_profile131.hpp and analysis/menu-fog-vertex-profiles.py/.json; original reference sources and original clients were only read.
VertexColor exchanges the exact CUnit virtual43 data slot with an owned callback. Its native color reader consumes ARGB at +568/+554 (x86) or +6A4/+6AC (x64). Only alpha is temporarily set to 255 during the original callback, then restored, including structured exceptions; RGB, native result and changes made by the game during the callback retain precedence. No unit pointer survives the call.
Fast Menu exchanges CGlueMgr virtual12 and leases the speed of its three menu models at 100x, following the reference animation policy. Verified root frame members are +1A0 (x86) / +2D8 (x64); native getters and model-update consumers verify speed +188 / +2C8. Original elapsed/time/context, return values and completion callbacks are forwarded unchanged. Disabling restores each captured speed only while that same current model retains the tool's written value. The original animation-only implementation did not clamp the separate native duration return; the 2026-10-26 fix below adds that missing transition hook. It can run outside a match when the authorized Local configuration enables it.
Fog Click is an alert observer, not an input permission override. It registers an additional native event16 callback through the supplied engine registration API, retaining the original selection handler. Registration/removal call sites and packet field readers are captured separately on all four profiles. Only actions 1/3, participant slots 0..23 and counts 1..12 are accepted. The callback copies immutable unit IDs into a 96-event queue without retaining packet memory; existing UI updates process at most eight events per100ms and discard excess/stale work. Typed agent resolution, exact CUnit identity/IDs, current world, native owner, unit visibility and terrain fog are checked. Shared vision uses the native ten-element CInteger alliance array (kind5), including grantors' terrain layers. Notifications are local, deduplicated for two seconds per player/unit/world; bursts or rapidly changing visibility can be missed, and no cheat verdict is inferred. No outgoing game action or chat message is submitted by these features.
The two callback exchanges alter only checked vtable data slots, restore page protections, refuse foreign replacements and attempt exact-owner restoration. They do not patch executable instructions, change stock frame levels or add workers/timers. Unavailable profiles, native state or writable data slots refuse the affected operation and are reported in WHT.log. Fog observer API registration is requested via a void engine API; actual event delivery remains pending live validation. Match reset disables the unit callback and removes the observer; expired authorization/settings disable menu acceleration as well. Saved INI keys and existing frame levels 7/8/9 are retained.
Validation: final x86 CTest2/2 and x64 CTest1/1 passed (analysis/menu-fog-vertex-x86.log and menu-fog-vertex-x64.log). Added isolated tests cover read-only data-slot ownership/protection/restoration, native callback ABI/results, scoped alpha/RGB and exception restoration, three model speed leases, exact position-property ABI, packet decoding/bounds/immutability, disabled zero reads, bounded queue, observer registration lifecycle, deduplication, visibility policy, and relocated signatures/tampering for both builds. These tests do not operate a live renderer or deliver live selection packets. Four runtime-test variants installed with backups and eight artifact hashes verified (analysis/menu-fog-vertex-installed-hashes.json); eight INI/log/macro hashes preserved (menu-fog-vertex-preserved.json). Actual visual behavior, native observer delivery, transition timing and multiplayer remain unverified in a match.


Tooltip update (2026-10-26): both native UI loops now update hover help using client coordinates. Menu controls, labels, tabs, macro actions and visible HUD action buttons show localized help after 300 ms; help hides when focus leaves the game. Menu help takes priority over HUD help. Added English descriptions for recovery, fog selection, FPS/VSync and common displays. Gameplay behavior is unchanged. x86 and x64 build/contracts passed; in-game visual verification remains pending.


Notification parity update (2026-10-26): retained the 1.29 formatter (yellow text, green ON/settings values, red OFF), native message position and four-second lifetime. Aligned command toggle titles, FPS/VSync priority feedback, potion registration and mana threshold text, macro arguments, and MTH Goku notices with the reference. Self-reporting recovery, skill, courier and HP-bar commands no longer emit a second generic OK. Repaired localized courier strings and only mark a queued MTH notice as published after the native renderer accepts it. Both architectures are covered by notification contracts; in-game visual comparison remains pending.


Latest-reference notification audit (2026-10-26): compared WHT/native/runtime.cpp and gameplay_commands.hpp with WHT-1.29/native/version129.cpp. All three notification_text.hpp files have the same SHA256 (see analysis/notification-latest-reference.json); retained the shared yellow/green/red formatting and four-second local native display. Added reference Repeat queue count, stop and validation feedback through a shared x86/x64 callback; added potion validation feedback; aligned courier assignment/base/return acknowledgement text; removed duplicate generic Repeat and MTH crafting acknowledgements. Kept truthful 1.31 runtime result messages where action confirmation differs. Added exact-string and single-notification contracts. Runtime visual comparison remains pending.


Graphics command parity (2026-10-26): added #fastmenu [0|1] and #unlockfps [0|1], with bare commands toggling the saved setting, as in WHT-1.29. They reuse Event/Fast Menu and Graphics/Unlock Limit FPS, existing reload/menu feedback, and independently guarded native 1.31 services. FPS unlock preserves VSync; when VSync is ON its preference remains saved but inactive, with explanatory feedback. Both commands reject invalid values, extra arguments, newline/NUL and failed saves. No new native addresses, hooks, threads or timers. Use #fastmenu 0 or #unlockfps 0 to disable. In-game transition/FPS verification remains pending.


Fast Menu transition-wait fix (2026-10-26): WHT accelerates model animation AND shortens the native transition return. The earlier 1.31 port only accelerated models, so it could still wait for the original transition duration. Added a separate independently verified six-argument native transition hook: x86 12164 +9D3F00 / 12173 +994C40; x64 12164 +AF7150 / 12173 +B3FB30. Full function bodies, original completion-callback relocation and x64 pointer/stack argument use were inspected in captured images; generated guards/evidence are in fast_menu_transition_profile131.hpp and analysis/fastmenu-duration-profiles.py/.json. The original function is called exactly once with unchanged sequence, arguments, callback and context; finite waits above .001 seconds are capped at .001 only while authorized Local Fast Menu is enabled. Zero/negative/nonfinite/already-short durations retain native values, following current 1.29 policy. Disabling immediately restores native returned durations; the existing model-speed leases restore owned values. Duration validation is independent of unrelated fog/vertex validation. Installation/refusal and actual transition/shortened counts are logged; refusal leaves duration untouched. Tooltip text updated. Both-build fixture/tamper checks and forwarding/disabled/edge-duration contracts added. No game process was launched for visual validation in this change; native installation and perceived transition timing remain pending live confirmation. Restart the test client to load the new MIX, enable #fastmenu 1, then switch Warcraft menu screens.


Selected-unit information commands (2026-10-26): added #upos (selected-unit X/Y, five decimal places) and #cname (four-character rawcode plus hexadecimal ID), with formatting matching UnitPositionText129/UnitCodeText129. Reads reuse independently verified 1.31 CUnit identity/type-field profiles (x86 +34, x64 +58) and native position getters/property offsets from existing guarded network profiles. Captures selected pointer and object tags before and after the read; invalid types, missing IDs/rawcodes, selection/recycled-ID changes and nonfinite coordinates are refused. No ownership override, game write or order is performed. Commands accept no arguments and publish once through LocalInfo/native notification; generic OK is suppressed. Contracts cover stable/recycled/changed selection, invalid fields and argument/formatting parity. In-game confirmation remains pending.


Icon/button press animation (2026-10-26): HUD icons now use the shared reference toolbar press policy: 180 ms quadratic return, .001 inset, .0004/- .0004 shift, 40% initial dimming and the pressed texture during the pulse. Auto Pick keeps reference active green (#44ff3d). MTH buttons use the reference 140 ms .0012/- .0012 depression; labels turn orange during press, while Goku retains its active green/yellow state. Visual geometry changes leave logical hit rectangles fixed. Mouse-up outside remains consumed and does not repeat the action or prematurely cancel the visual pulse. Hidden/reset controls cancel animation. Uses existing UI updates, no added timer/thread, gameplay action or frame-level changes. The existing independently guarded 1.31 texture-tint profile is now supplied to ToolMenuOverlay for both architectures (supplied frame APIs previously left this pointer null). Animation/color/asset updates are cached. Tests cover timing/easing, colors, outside release, one action and stable hitboxes. Actual in-game visual comparison remains pending.


Fog/vertex command parity (2026-10-26): added #fogclick [0|1] / #fc [0|1] for Event/Fog Click and #vertexcolor [0|1] for Graphics/VertexColor. Bare commands toggle the persisted value; saved settings and menu checkboxes share the existing Config fields. These reuse the independently guarded 1.31 fog-selection observer and vertex-alpha callback, without adding native addresses, hooks or game orders. Fog Click is an alert preference, not a change to selection permissions. Feedback uses current 1.29 titles Fog Click and VertexColor. Tests cover aliases, independent settings, menu agreement, reference feedback, malformed arguments/NUL and failed saves. Actual live event delivery and vertex appearance remain pending verification.


Latest producer-side notification parity (2026-10-26): re-read current WHT and WHT-1.29. The common color formatter was already identical, but current 1.29 added LegacySettingNotice129 ([WHT] + SettingFeedback) at notification producers. Added equivalent LegacySettingNotice131 for menu checkbox/key/value edits, camera and supported saved-option commands. Aligned reference setting titles (ShowCooldown, ShowRegenHP, ShowLevelHero, BlackBarUI, etc.), scroll key/value format, modecast Set Normal/Quick Cast and MTH group notices. Kept reference-style direct action feedback for Fog Click, Auto Click and command/menu state. Added a thread-local successful-dispatch sequence and outer command checks in x86/x64 so handlers that already displayed a result cannot also emit a generic success. Deferred/asynchronous notices retain existing explicit suppression. 1.31 keeps truthful live-VSync/native-FPS restoration wording; no unsupported default-60-FPS or restart claim was copied. Exact-string prefix/color/menu/scroll/mode/sequence tests added. Reference hashes and findings: analysis/legacy-notice-reference.json. Native message placement, font and four-second lifetime unchanged; actual in-game visual comparison remains pending.


VSync/menu command completion (2026-10-26): added #vsync [0|1], with bare toggle, persisting Graphics/Vsync (same case-insensitive key as the VSync checkbox). Reuses guarded native PresentationService131 on both architectures; VSync priority is retained and the saved FPS-unlock preference is preserved. No restart requirement is imposed for this live 1.31 service. Feedback follows current reference [WHT] Set Vsync: ON/OFF. Added #tools as an alias of the existing tool/menu toggle, sharing a strict no-argument parser with #tool/#menu; malformed arguments and newline/NUL do not toggle. Tests cover persistence, menu agreement, bare/explicit states, saved unlock preference, failed-save behavior, aliases and feedback. No new native address/hook/timer/thread. Actual live VSync behavior remains pending verification.


Host-only ban/kick (2026-10-26)

Added #kick <1..24 or exact name>, #ban <1..24 or "exact name"> [reason], and #openbl. Load/authorize the tool in Local mode before hosting and before players join so it can observe the complete handshake. This is the 1.29 host-owned-connection scope, not a remote host-bot administration channel. No 1.29 gameplay header or game offset is enabled: host_moderation131.hpp and player_network131.hpp independently track framed protocol traffic, recipient IDs, local identity and current human slots. Existing verified 1.31 profiles supply local player names when a world is available; registry userlocal is a lobby fallback. A complete runtime host proof is required before any shutdown, including automatic bans. Unsupported/encrypted traffic remains unavailable.

Ban entries use TS-Banned.ini / [Banned List], keyed by name with the saved reason. #openbl opens this file for editing/removing entries. Duplicate names/connections, own player, missing/closed/reused sockets, stale I/O completions, unknown local host identity, invalid arguments and failed ban persistence are refused. Ban persistence precedes shutdown; a failed shutdown can still leave a successfully saved ban, and the result says so. Automatic ban checks use a 250 ms cadence and at most two failed shutdown attempts per connection. Successfully requested shutdowns are not repeated. Name-based bans have the same rename/account limitations as the reference.

Observers preserve system API arguments, return values and last-error state. Sync reads, partial sends, fragmented/coalesced frames and IOCP/WSAGetOverlappedResult completions are handled; unsupported completion-routine callbacks revoke proof rather than guessing. Socket/room epochs prevent late completions from binding a recycled handle. No packet is fabricated or native host-privilege flag modified. Moderation chat Enter is consumed locally and Escape closes the edit. Results always go to WHT.log and use the existing game notification when CGameUI is available; a native lobby message pane is not implemented.

Tests include protocol direction/schema/identity, self/duplicate/closed-peer refusal, malformed input and UTF8, authorization loss, late completions, actual partial byte counts, bounded auto-ban attempts, original Winsock errors and nested observation, a real loopback TCP shutdown of a test-owned peer, and actual temporary-INI name/reason persistence. These are local contracts, not a live Warcraft/Battle.net validation. Runtime host-handshake recognition and actual player departure in all four game variants remain pending live verification. See analysis/host-moderation131-audit.json for the scope and reference hashes.


Lobby regression correction (2026-10-26): removed synthetic Escape after local moderation commands on x86/x64. Runtime moderation hooks, disconnects and automatic ban enforcement are disabled pending validation against actual 1.31 lobby transport. #kick/#ban explicitly report unavailable and do not modify the ban list. #openbl remains available. Protocol/loopback tests do not establish live-game compatibility.

Chat Enter correction (2026-10-26): moderation commands now follow the ordinary command input path. Neither Enter keydown nor carriage-return WM_CHAR is swallowed; Warcraft handles chat submission/closure normally. No synthetic Escape. Command text can appear in chat, as with other tool commands. Kick/ban remain unavailable pending actual 1.31 transport validation.

Moderation investigation (2026-10-26): WHT 1.24/1.26 uses a version-specific IOCP connection layout plus native lobby host/slot/local-ID getters; those offsets are not valid 1.31 profiles. Enable standard Winsock observation only, with no packet changes, disconnect or automatic ban enforcement. WHT.log records bounded aggregate counters (bytes, join directions, outgoing slot/player frames, rejected frames, unsupported I/O, identity resets, current candidate proof); no packet bodies, player names or addresses. A candidate packet handshake does not authorize disconnect. Recreate the room after authorization so join traffic can be observed. No actual two-client 1.31 kick has been validated.

Follow-up real-room log (2026-10-26, x86 build 12164): two incoming joins and two outgoing player-info frames observed, zero accepted outgoing slot-join frames, 83 rejected frames and one local-identity reset. This does not prove a slot layout. Add bounded structural slot/rejection diagnostics before enabling any disconnect: packet type/direction/length, slot-info length/count, expected layout length, peer record presence and client flag. Runtime kick/ban remains disabled.

AcceptEx follow-up (2026-10-26): actual x86 room emits a valid nine-byte-slot SLOTINFOJOIN (111 bytes, info length 88, nine rows), but its accepted peer is missing. Add standard Winsock AcceptEx initial-receive tracking using the accepted socket and actual IOCP completion bytes; extension pointer resolved by WSAIoctl. Real loopback AcceptEx/IOCP test covers this previously missing path. First local identity acquisition preserves previously captured handshake, while subsequent identity changes still clear room state. Prefix moderation logs with PID because two local clients share WHT.log. Runtime disconnect remains gated off pending actual complete host proof.

Receive-path follow-up (2026-10-26): confirmed latest x86 binary loaded; PID 11408 sees 17 AcceptEx calls but zero incoming joins. AcceptEx-only hypothesis is insufficient. Handle synchronous successful overlapped completion immediately (deduplicate later completion); add recvfrom/WSARecvFrom and ReadFile on accept/AcceptEx-owned socket handles, plus GetOverlappedResult/Ex. Ordinary file reads are forwarded without buffer inspection. Real socket ReadFile/IOCP and synchronous completion regressions pass. No complete actual-game peer mapping has been demonstrated; kick/ban remains disabled. A fresh room/join alone suffices for next capture; issuing moderation commands while disabled is unnecessary.

Host-slot fix (2026-10-26): actual running x86 12164 room provides SLOTINFOJOIN recipient 2 before recipient 2 has an occupied row. Prior parser incorrectly rejected this and discarded its incoming-join socket. Preserve unique assigned ID/socket binding and wait for subsequent occupied human slot before allowing disconnect/ban. Host identity may use the unique non-peer human row only with locally sent PLAYERINFO; ambiguous rows refuse inference. Enable moderation for authorized Local-mode x86 build 12164 only, still requiring full runtime host proof and exact target mapping. x86 12173 and all x64 remain disabled. Tests reproduce staged initial slot/update and confirm no early disconnect, exact subsequent target, ambiguous host refusal and persistence. No actual multiplayer disconnect is yet confirmed. This supersedes the earlier blanket runtime-disable notes.

Moderation across supported profiles (2026-10-26): enable the independent standard Winsock host-moderation transport on builds 12164 and 12173, both x86 and x64. Native identity reads retain their existing architecture/build-specific verified Resource profiles; no inherited 1.29 offsets are enabled. All four targets still require authorization, Local mode and a complete runtime host/accepted-peer/occupied-slot match. Unsupported builds refuse action. Retain staged SLOTINFOJOIN handling, native-width SOCKETs, self/ambiguity/stale-socket checks and TS-Banned.ini schema. Both architectures run real TCP, AcceptEx, socket ReadFile/IOCP and persistence tests. Actual multiplayer disconnect has not been confirmed on every profile; host-bot rooms do not grant this client host authority. This supersedes the prior x86-12164-only activation note.

Command compatibility (2026-10-26): shared aliases on all four profiles: #sell and #quicksell -> #sellall; #showcooldown -> #cooldown; #hotkeypanel -> #showhotkey; #showresource -> #res. Matches WHT-1.29 parity alias semantics. Dispatch and feedback use the same canonical name, preserving authorization, existing native feature gates, argument parsing and persistence. Sell aliases keep the existing sell-all result notification, avoiding duplicate success notices. These are alternate command names for already ported features, not new native implementations.
