#include <windows.h>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <vector>
#include <iostream>
#include <stdexcept>
namespace fs=std::filesystem;
void require(bool ok,const char* text){if(!ok)throw std::runtime_error(text);}
int wmain(int argc,wchar_t** argv){try{
 require(argc==4,"archive, Storm DLL and output directory required");
 auto storm=LoadLibraryW(argv[2]);require(storm!=nullptr,"Storm helper unavailable");
 auto open=reinterpret_cast<BOOL(WINAPI*)(const char*,DWORD,DWORD,HANDLE*)>(GetProcAddress(storm,MAKEINTRESOURCEA(266)));
 auto close=reinterpret_cast<BOOL(WINAPI*)(HANDLE)>(GetProcAddress(storm,MAKEINTRESOURCEA(252)));
 auto fileOpen=reinterpret_cast<BOOL(WINAPI*)(HANDLE,const char*,DWORD,HANDLE*)>(GetProcAddress(storm,MAKEINTRESOURCEA(268)));
 auto fileClose=reinterpret_cast<BOOL(WINAPI*)(HANDLE)>(GetProcAddress(storm,MAKEINTRESOURCEA(253)));
 auto read=reinterpret_cast<BOOL(WINAPI*)(HANDLE,void*,DWORD,DWORD*,OVERLAPPED*)>(GetProcAddress(storm,MAKEINTRESOURCEA(269)));
 require(open&&close&&fileOpen&&fileClose&&read,"Storm helper API unavailable");
 const unsigned char seed[]={0xb8,1,0,0x10,0,0xe8};void* init=nullptr;auto code=reinterpret_cast<const unsigned char*>(open);
 for(size_t n=0;n<160;++n)if(!memcmp(code+n,seed,sizeof(seed))){int r=0;memcpy(&r,code+n+6,4);init=const_cast<unsigned char*>(code+n+10+r);break;}
 require(init!=nullptr,"MPQ initializer missing");
 __asm { mov eax, 100001h }
 __asm { call init }
 HANDLE archive=nullptr;require(open(fs::path(argv[1]).string().c_str(),30,0,&archive)&&archive,"archive open failed");
 auto content=[&](const std::string& name){HANDLE file=nullptr;require(fileOpen(archive,name.c_str(),0,&file)&&file,"asset missing");std::vector<char> bytes;char chunk[65536];
  for(;;){DWORD count=0;const bool ok=read(file,chunk,sizeof(chunk),&count,nullptr)!=FALSE;bytes.insert(bytes.end(),chunk,chunk+count);require(bytes.size()<64*1024*1024,"asset too large");if(!ok||count<sizeof(chunk))break;}
  fileClose(file);return bytes;};
 auto list=content("(listfile)");std::istringstream names(std::string(list.begin(),list.end()));auto root=fs::absolute(argv[3]).lexically_normal();fs::create_directories(root);std::string name;size_t count=0;
 while(std::getline(names,name)){
  if(!name.empty()&&name.back()=='\r')name.pop_back();if(name.empty()||name[0]=='(')continue;
  fs::path relative(name);require(!relative.is_absolute()&&!relative.has_root_name(),"absolute asset path rejected");
  for(const auto& part:relative)require(part!=L"..","asset traversal rejected");
  const auto bytes=content(name);auto dest=root/relative;fs::create_directories(dest.parent_path());std::ofstream out(dest,std::ios::binary|std::ios::trunc);out.write(bytes.data(),bytes.size());require(out.good(),"asset write failed");++count;
 }
 // Only these two retired aliases belonged to the generated asset bundle.
 for(const auto* name:{L"AARDV.ttf",L"WHTUI_FRIZQT__.ttf"})fs::remove(root/name);
 close(archive);FreeLibrary(storm);
 for(const auto* name:{L"fonts_VN.ttf",L"Transparent.tga",L"BTNWHT_Menu.blp",L"BTNWHT_Rec.blp",L"WHTUI_GreyBackground.tga"})require(fs::exists(root/name),"required UI asset missing");
 std::cout<<"Extracted "<<count<<" exact WHT assets\n";return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
