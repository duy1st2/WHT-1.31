using System.Security.Cryptography;
using System.Text.Json;
using System.Text.RegularExpressions;

try {
    if (args.Length != 2) return 1;
    ConfigurationCipher.SelfTest();
    string source = File.ReadAllText(Path.Combine(args[0], "connect", "DBConnection.vb"));
    string ReadField(string name) {
        var match = Regex.Match(source, name + "\\s+As\\s+String\\s*=\\s*\"([^\"]+)\"", RegexOptions.IgnoreCase);
        if (!match.Success) throw new InvalidDataException();
        return match.Groups[1].Value;
    }
    byte[] clear = JsonSerializer.SerializeToUtf8Bytes(new { connectionString = ReadField("_connectionString"), database = ReadField("_databaseName") });
    byte[] key = RandomNumberGenerator.GetBytes(32);
    try {
        Directory.CreateDirectory(args[1]);
        File.WriteAllBytes(Path.Combine(args[1], "mongo.enc"), ConfigurationCipher.Encrypt(clear, key));
        File.WriteAllBytes(Path.Combine(args[1], "mongo.key"), key);
    } finally { CryptographicOperations.ZeroMemory(clear); CryptographicOperations.ZeroMemory(key); }
    Console.WriteLine("PASS AES-256-GCM sealing and tamper rejection");
    return 0;
} catch { Console.Error.WriteLine("Configuration sealing failed"); return 1; }
